const mondai = [
    { number: 1, question: '問題１', answer: '問題１の答え', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '問題３', answer: '問題３の答え', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '問題６', answer: '問題６の答え', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '問題７', answer: '問題７の答え', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '問題８', answer: '問題８の答え', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '問題１２', answer: '問題１２の答え', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '問題１４', answer: '問題１４の答え', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: '問題１５', answer: '問題１５の答え', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: '問題１６', answer: '問題１６の答え', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: '問題１９', answer: '問題１９の答え', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''}
];