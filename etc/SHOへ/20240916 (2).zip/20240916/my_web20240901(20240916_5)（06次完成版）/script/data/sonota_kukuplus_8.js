const mondai = [
    { number: 1, question: '5×1＝', answer: '5', image_name: '', answer2: '5', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '5×2＝', answer: '10', image_name: '', answer2: '10', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '5×3＝', answer: '15', image_name: '', answer2: '15', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '5×4＝', answer: '20', image_name: '', answer2: '20', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '5×5＝', answer: '25', image_name: '', answer2: '25', etc_2: '', etc_3: '', etc_4: ''}
];