const mondai = [
    { number: 1, question: '「ぴゃ」をローマ字で書きましょう。', answer: 'pya', image_name: '', answer2: 'pya', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '「ぴゅ」をローマ字で書きましょう。', answer: 'pyu', image_name: '', answer2: 'pyu', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '「ぴょ」をローマ字で書きましょう。', answer: 'pyo', image_name: '', answer2: 'pyo', etc_2: '', etc_3: '', etc_4: ''}
];