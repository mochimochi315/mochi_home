const mondai = [
    { number: 1, question: 'P100。おとりのがんは、必死になって逃げている時に、なぜじいさんの所に方向を変えたのですか。<BR>じいさんが（　　　いた）から。', answer: 'くちぶえをふいた', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P101。残雪が、はやぶさにぶつかっていったのはなぜですか。<BR>仲間を（　　　）ため。', answer: 'すくう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P101。12行目の「てき」とは誰ですか。', answer: 'はやぶさ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P101。残雪は、はやぶさに勝つことができると思って、体当たりをしたのですか。<BR>「はい」か「いいえ」で答えましょう。', answer: 'いいえ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P102。はやぶさは、大造じいさんを見て、どうしましたか。<BR>急に戦いをやめて、（　　　いった）。', answer: 'よろめきながらとびさっていった', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P102。戦いの後、残雪は、どうしていましたか。<BR>むねのあたりを（　　　そめて）、ぐったりとしていた。', answer: 'くれないにそめて', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P102。第二のおそろしい「てき」とは誰ですか。', answer: 'だいぞうじいさん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P102。大造じいさんを見て、残りの力をふりしぼって、（　　　）を持ち上げた。', answer: 'ぐっとながいくび', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P102。大造じいさんを見て、じいさんを正面から（　　　つけた）。', answer: 'にらみつけた', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'P103。大造じいさんは、なぜ強く心を打たれたのですか。<BR>もうすぐ命を落とすかもしれないにもかかわらず、残雪は（　　　）としてのいげんをきずつけまいと、努力していていたから。（大造じいさんには、そのように見えたから。）', answer: 'とうりょう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];