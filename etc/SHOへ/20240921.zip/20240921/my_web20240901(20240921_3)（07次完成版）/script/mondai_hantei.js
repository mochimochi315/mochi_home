//このファイルの中に、「'use strict';」を記述するとエラーになる。

let mondai_hantei = [
    { number: 1, hantei: "no" },
    { number: 2, hantei: "no" },
    { number: 3, hantei: "no" },
    { number: 4, hantei: "no" },
    { number: 5, hantei: "no" },
    { number: 6, hantei: "no" },
    { number: 7, hantei: "no" },
    { number: 8, hantei: "no" },
    { number: 9, hantei: "no" },
    { number: 10, hantei: "no" },
    { number: 11, hantei: "no" },
    { number: 12, hantei: "no" },
    { number: 13, hantei: "no" },
    { number: 14, hantei: "no" },
    { number: 15, hantei: "no" },
    { number: 16, hantei: "no" },
    { number: 17, hantei: "no" },
    { number: 18, hantei: "no" },
    { number: 19, hantei: "no" },
    { number: 20, hantei: "no" }
];


