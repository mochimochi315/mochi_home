const mondai = [
    { number: 1, question: '3×0＝', answer: '0', image_name: '', answer2: '0', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '3×6＝', answer: '18', image_name: '', answer2: '18', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '3×7＝', answer: '21', image_name: '', answer2: '21', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '3×8＝', answer: '24', image_name: '', answer2: '24', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '3×9＝', answer: '27', image_name: '', answer2: '27', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '3×10＝', answer: '30', image_name: '', answer2: '30', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '4×0＝', answer: '0', image_name: '', answer2: '0', etc_2: '', etc_3: '', etc_4: ''}
];