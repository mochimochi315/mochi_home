const mondai = [
    { number: 1, question: "問題１", answer: 1, length: 1 },
    { number: 2, question: "問題２", answer: 2, length: 1 },
    { number: 3, question: "問題３", answer: 3, length: 1 },
    { number: 4, question: "問題４", answer: 4, length: 1 },
    { number: 5, question: "問題５", answer: 5, length: 1 },
    { number: 6, question: "問題６", answer: 6, length: 1 },
    { number: 7, question: "問題７", answer: 7, length: 1 },
    { number: 8, question: "問題８", answer: 8, length: 1 },
    { number: 9, question: "問題９", answer: 9, length: 1 },
    { number: 10, question: "問題１０", answer: 10, length: 1 }
];
