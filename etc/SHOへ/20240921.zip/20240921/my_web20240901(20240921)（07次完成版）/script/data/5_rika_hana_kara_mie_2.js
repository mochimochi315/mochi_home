const mondai = [
    { number: 1, question: 'Bの部分は、何といいますか？（すべてひらがなで）', answer: 'たいぶつれんず', image_name: '5-rika-1-08.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'Aの部分は、何といいますか？', answer: 'ちょうせつねじ', image_name: '5-rika-1-09.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'Bの部分は、何といいますか？', answer: 'はんしゃきょう', image_name: '5-rika-1-10.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'プレパラートを（　　　）に動かす。', answer: 'ひだりした', image_name: '5-rika-1-11.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'まず（　　い）倍率で、見るものが真ん中になるようにしておく。', answer: 'ひくい', image_name: '5-rika-1-12.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'はっきり見えなければ（　　　）を少しずつ回して、ピントを合わせる。', answer: 'ちょうせつねじ', image_name: '5-rika-1-13.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'Aの部分は、（　　　）になる部分です。', answer: 'み', image_name: '5-rika-1-14.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];