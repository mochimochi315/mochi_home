const mondai = [
    { number: 1, question: 'goo辞書を使って、意味調べをしましょう。<BR>P90。率（ひき）いる…（　　　つれて）行く。', answer: 'ひき', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'goo辞書を使って、意味調べをしましょう。<BR>P90。頭領（とうりょう）…（　　　）のかしら。', answer: 'しゅうだん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'goo辞書を使って、意味調べをしましょう。<BR>P90。あさる…（　　　）がえさや獲物（えもの）を探（さが）し求める。', answer: 'どうぶつ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'goo辞書を使って、意味調べをしましょう。<BR>P91。いまいましい…非常（ひじょう）に（　　　く）感じる。', answer: 'はらだたしく', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'goo辞書を使って、意味調べをしましょう。<BR>P91。かねて…（　　　）から。', answer: 'まえ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'goo辞書を使って、意味調べをしましょう。<BR>P92。羽音（はおと）…（　　　）がはばたく音。', answer: 'とり', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'goo辞書を使って、意味調べをしましょう。<BR>P93。けいせき…（　　　）があったあと。', answer: 'なにか', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'goo辞書を使って、意味調べをしましょう。<BR>P93。こりる…失敗して（　　　）にあい、もうやるまいと思う。', answer: 'ひどいめ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'goo辞書を使って、意味調べをしましょう。<BR>P93。今さら…（　　　）になって。', answer: 'いまごろ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'goo辞書を使って、意味調べをしましょう。<BR>P94。会心（かいしん）…期待どおりにいって（　　　）すること。', answer: 'まんぞく', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];