const mondai = [
    { number: 1, question: '7×6＝', answer: '42', image_name: '', answer2: '42', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '7×7＝', answer: '49', image_name: '', answer2: '49', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '7×8＝', answer: '56', image_name: '', answer2: '56', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '7×9＝', answer: '63', image_name: '', answer2: '63', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '7×10＝', answer: '70', image_name: '', answer2: '70', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '8×0＝', answer: '0', image_name: '', answer2: '0', etc_2: '', etc_3: '', etc_4: ''}
];