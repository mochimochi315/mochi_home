const img_seikai = ["images/seikai/2001.png", "images/seikai/2002.png", "images/seikai/2003.png",
    "images/seikai/2004.png", "images/seikai/2005.png", "images/seikai/2006.png",
    "images/seikai/2007.png", "images/seikai/2008.png", "images/seikai/2009.png",
    "images/seikai/2010.png", "images/seikai/2011.png", "images/seikai/2012.png",
    "images/seikai/2013.png", "images/seikai/2014.png", "images/seikai/2015.png",
    "images/seikai/2016.png", "images/seikai/2017.png", "images/seikai/2018.png", "images/seikai/2019.png"];
