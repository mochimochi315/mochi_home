const mondai = [
    { number: 1, question: '「ぴゃ」をローマ字で書きましょう。', answer: '', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '「ぴゅ」をローマ字で書きましょう。', answer: '', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '「ぴょ」をローマ字で書きましょう。', answer: '', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''}
];