const mondai = [
    { number: 1, question: 'たとえば、第1場面が1965年だっとします。第2場面は、何年でしょう。', answer: '1966', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'たとえば、第1場面が1965年だっとします。第3場面は、何年でしょう。', answer: '1967', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'たとえば、第1場面が1965年だっとします。第4場面は、何年でしょう。', answer: '1968', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '残雪は、いつの季節にやって来ますか。', answer: 'あき', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P92。じいさんは、なぜ、「ほほう、これはすばらしい！」と言ったのですか。<BR>（　　　）がうまく手に入ったから。', answer: 'いきているがん', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P92。付近には一羽もいなくなったのはなぜですか。<BR>がんの群れが危険を感じて、（　　　）を変えたから', answer: 'えば', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P92。たかが鳥のことだ、とおもったじいさんは、どうしましたか。<BR>（　　　）をばらまいておいた。', answer: 'もっとたくさんのつりばり', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P92。じいさんは、なぜ「はてな。」と思ったのですか。<BR>（　　　）が飛び立ったから。', answer: 'がんのたいぐん', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P93。確かにがんが（　　　）があるのに、今日は一羽もはりにかかっていない。', answer: 'えをあさったけいせき', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'P93。つりばりの糸が、みな、ぴんと（　　　ある）。', answer: 'ひきのばされてある', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''}
];