const mondai = [
    { number: 1, question: 'goo辞書を使って、意味調べをしましょう。<BR>P102。いげん…近寄（ちかよ）りがたいほど堂々（どうどう）として（　　　）なこと。', answer: 'おごそか', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'goo辞書を使って、意味調べをしましょう。<BR>P104。快（こころよ）い…（　　　）よく感じられる。', answer: 'きもち', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'goo辞書を使って、意味調べをしましょう。<BR>P104。らんまん…（　　　）が咲（さ）き乱（みだ）れているさま。', answer: 'はな', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'goo辞書を使って、意味調べをしましょう。<BR>P105。はればれ…少しもわだかまりなどがなく、気持ちが（　　　）としたさま。', answer: 'さっぱり', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''}
];