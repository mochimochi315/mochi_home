const mondai = [
    { number: 1, question: '「る」をローマ字で書きましょう。', answer: 'ru', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '「れ」をローマ字で書きましょう。', answer: 're', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '「ろ」をローマ字で書きましょう。', answer: 'ro', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '「わ」をローマ字で書きましょう。', answer: 'wa', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '「を」をローマ字で書きましょう。', answer: 'wo', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '「ん」をローマ字で書きましょう。', answer: 'nn', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '「が」をローマ字で書きましょう。', answer: 'ga', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: '「ぎ」をローマ字で書きましょう。', answer: 'gi', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: '「ぐ」をローマ字で書きましょう。', answer: 'gu', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: '「げ」をローマ字で書きましょう。', answer: 'ge', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 11, question: '「ご」をローマ字で書きましょう。', answer: 'go', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''}
];