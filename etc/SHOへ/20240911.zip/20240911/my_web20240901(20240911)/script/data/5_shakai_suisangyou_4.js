const mondai = [
    { number: 1, question: 'P89。黒潮の速い流れにのって、太平洋側から多くの（　　　）がやってきます。', answer: 'さかな', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P91のウを見て答えましょう。<BR>さんま漁では多くの（　　　）を使うので、燃料もたくさん必要になります。', answer: 'でんきゅう', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P92。多くの人で競争をして、魚のねだんを決めていく方法を（　　　）という。', answer: 'せり', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P93。さんまを大きさによって選別する作業などは、（　　　）が自動で行うようになっています。', answer: 'きかい', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P94のアを見て答えましょう。<BR>さんまは（　　　）トラックに積み込まれ、出発します。', answer: 'ほれい', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P95。大洗（おおあらい）港からトラックに積まれたさんまは、朝の４時頃に、東京都（　　　）卸売（おろしうり）市場に到着（とうちゃく）します。', answer: 'ちゅうおう', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P95のカを見て答えましょう。<BR>さんまの値段（ねだん）にふくまれている費用の中には、（　　　）で売られる値段（ねだん）も含まれている。', answer: 'みせ', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P98のエを見て答えましょう。<BR>1980年と比べると、2020年の輸入量は、（　　　　いる）。', answer: 'ふえている', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P99。根室（ねむろ）半島のすぐ近くには、ロシアが不法に占領（せんりょう）している（　　　）の島々があり、<BR>根室の水産業に大きなえいきょうをあたえています。', answer: 'ほっぽうりょうど', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'P100のアを見て答えましょう。<BR>2017年の世界の水産物消費量は、1980年と比べて（　　　いる）。', answer: 'ふえている', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''}
];