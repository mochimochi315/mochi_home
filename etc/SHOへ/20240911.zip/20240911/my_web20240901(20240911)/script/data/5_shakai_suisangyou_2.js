const mondai = [
    { number: 1, question: 'P88。海岸ぞいでは、水産物を育ててとる（　　　）も行われています。', answer: 'ようしょくぎょう', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P89のオを見て答えましょう。<BR>水産物の一番多い都道府県はどこですか。', answer: 'ほっかいどう', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P89のエを見て答えましょう。<BR>南からは、黒潮と呼ばれる（　　）が流れてきています。', answer: 'だんりゅう', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P91のエを見て答えましょう。<BR>船には、（　　　）を発信・受信する機械を積んでいます。', answer: 'ちょうおんぱ', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P92のウを見て答えましょう。<BR>根室市の（　　　）人以上の人々が、漁業や水産物に関わる仕事についています。', answer: '5000', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P93。紫外線（しがいせん）で殺菌（さっきん）した（　　　）と、<BR>氷をいっしょに箱づめして、さんまを出荷（しゅっか）しています。', answer: 'かいすい', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P95。急ぐ場合には、（　　　）を利用してさんまを運ぶこともあります。', answer: 'こうくうき', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P96のオを見て答えましょう。<BR>（　　　）が大きくなると、ぶりという名前に変わります。', answer: 'はまち', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P98のウを見て答えましょう。<BR>海水の温度が上がると、漁場が（　　　　）。', answer: 'とおくなる', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'P101のオを見て答えましょう。<BR>あみの目にひっかからないのは、大きな魚、小さな魚のどちらですか。', answer: 'ちいさなさかな', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''}
];