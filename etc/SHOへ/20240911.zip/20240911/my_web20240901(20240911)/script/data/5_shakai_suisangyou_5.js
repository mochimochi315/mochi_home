const mondai = [
    { number: 1, question: 'P89。陸地の周りの水深（　　　メートル）ぐらいのまでの海では、<BR>太陽の光がとくとどき、プランクトンや海藻などがよく育ちます。', answer: '200', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P92。せりでは、水産物の状態や水あげ量をみて、（　　　）が決められている。', answer: 'ねだん', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P92のオを見て答えましょう。<BR>さんまの水あげがさかんな時期のさんまの値段（ねだん）は、１㎏（　　　）円です。', answer: '200', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P95。さんまを積んだフェリーは、夕方の６時以降（いこう）に、（　　　）港に着きます。', answer: 'おおあらい', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P94～P95を見て答えましょう。<BR>さんまが水あげされてから、東京のスーパーマーケットで売られるまでに、約（　　　）日以上かかっています。', answer: '3', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P96。鹿児島県長島町では、（　　　）の養殖（ようしょく）がさかんです。', answer: 'ぶり', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P100。世界各国は、自国の水産資源物を守るために、<BR>海岸から200海里のはん囲の海で、<BR>他国の漁船がとる魚の種類や量を（　　　）するようになりました。', answer: 'せいげん', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P100。日本をはじめ、水産業のさかんな国々が集まって話し合い、<BR>漁船の数やとれる量、漁の期間などを決めて、（　　　）しようとしています。', answer: 'かんり', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P101のエを見て答えましょう。<BR>独立した国際機関がきびしく審査（しんさ）して、海の環境や水産資源を守りながら生産された（　　　　　）であることを示しています。', answer: 'すいさんぶつ', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'P101。水産資源を守り、増やすために、ようしょく業や（　　　　）を育てて海に放流する「さいばい漁業」も行われています。', answer: 'ちぎょ', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''}
];