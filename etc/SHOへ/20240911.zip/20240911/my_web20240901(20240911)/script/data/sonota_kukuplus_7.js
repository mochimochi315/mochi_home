const mondai = [
    { number: 1, question: '6×0＝', answer: '0', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '6×1＝', answer: '6', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '6×2＝', answer: '12', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '6×3＝', answer: '18', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '6×4＝', answer: '24', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '6×5＝', answer: '30', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '6×6＝', answer: '36', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: '6×7＝', answer: '42', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: '6×8＝', answer: '48', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: '6×9＝', answer: '54', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 11, question: '6×10＝', answer: '60', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''}
];