const mondai = [
    { number: 1, question: '7×0＝', answer: '0', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '7×1＝', answer: '7', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '7×2＝', answer: '14', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '7×3＝', answer: '21', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '7×4＝', answer: '28', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '7×5＝', answer: '35', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '7×6＝', answer: '42', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: '7×7＝', answer: '49', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: '7×8＝', answer: '56', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: '7×9＝', answer: '63', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 11, question: '7×10＝', answer: '70', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''}
];