const mondai = [
    { number: 1, question: 'P88。日本の全国各地には、2800近くの（　　　）がある。', answer: 'ぎょこう', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P89。親潮は栄養分が豊富で、魚介類のえさとなる（　　　）をたくさん育みます。', answer: 'プランクトン', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P89のエを見て答えましょう。<BR>水あげ量が一番多い漁港は（　　　）です。', answer: 'ちょうし', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P91のカを見て答えましょう。<BR>７月から９月にかけてとれる魚は（　　　）です。', answer: 'さんま', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P92。船に積んでいる魚を漁港にあげることを（　　　）という。', answer: 'みずあげ', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P92のオを見て答えましょう。<BR>さんまの水あげが少ない時期のさんまの値段（ねだん）は、1㎏（　　　）円です。', answer: '1000', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P93。さんまは、（　　　）が大事です。', answer: 'しんせんさ', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P94のイを見て答えましょう。<BR>さんまは、苫小牧（とまこまい）港で、（　　　）に乗船させられます。', answer: 'フェリー', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P97。近くの地域に向けては、とれたての状態（じょうたい）でぶりをとどけるために、<BR>（　　　）をのせたトラックや船をつかって、生きたまま消費地（しょうひち）へ運ぶ方法もあります。', answer: 'すいそう', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'P98。日本全体の漁業生産量は、昔と比べて大きく減ってきています。<BR>一方で、外国からの（　　　）にたよっている水産物もあります。', answer: 'ゆにゅう', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''}
];