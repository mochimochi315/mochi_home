const mondai = [
    { number: 1, question: '1×0＝', answer: '0', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '1×1＝', answer: '1', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '1×2＝', answer: '2', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '1×3＝', answer: '3', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '1×4＝', answer: '4', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '1×5＝', answer: '5', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '1×6＝', answer: '6', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: '1×7＝', answer: '7', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: '1×8＝', answer: '8', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: '1×9＝', answer: '9', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 11, question: '1×10＝', answer: '10', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''}
];