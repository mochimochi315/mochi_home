const mondai = [
    { number: 1, question: '4×0＝', answer: '0', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '4×1＝', answer: '4', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '4×2＝', answer: '8', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '4×3＝', answer: '12', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '4×4＝', answer: '16', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '4×5＝', answer: '20', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '4×6＝', answer: '24', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: '4×7＝', answer: '28', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: '4×8＝', answer: '32', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: '4×9＝', answer: '36', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 11, question: '4×10＝', answer: '40', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''}
];