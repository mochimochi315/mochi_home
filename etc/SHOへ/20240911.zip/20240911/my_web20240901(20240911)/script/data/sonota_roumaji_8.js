const mondai = [
    { number: 1, question: '「ぎょ」をローマ字で書きましょう。', answer: '', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '「じゃ」をローマ字で書きましょう。', answer: '', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '「じゅ」をローマ字で書きましょう。', answer: '', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '「じょ」をローマ字で書きましょう。', answer: '', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '「ぢゃ」をローマ字で書きましょう。', answer: '', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '「ぢゅ」をローマ字で書きましょう。', answer: '', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '「ぢょ」をローマ字で書きましょう。', answer: '', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: '「びゃ」をローマ字で書きましょう。', answer: '', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: '「びゅ」をローマ字で書きましょう。', answer: '', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: '「びょ」をローマ字で書きましょう。', answer: '', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''}
];