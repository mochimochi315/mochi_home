const mondai = [
    { number: 1, question: 'goo辞書を使って、意味調べをしましょう。<BR>P94。えみ…（　　　）とすること。', answer: 'にっこり', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'goo辞書を使って、意味調べをしましょう。<BR>P94。ねぐら…（　　　）の寝（ね）る所。', answer: 'とり', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'goo辞書を使って、意味調べをしましょう。<BR>P95。あかつき…（　　　）の昇（のぼ）る前のほの暗いころ。', answer: 'たいよう', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'goo辞書を使って、意味調べをしましょう。<BR>P95。すがすがしい…（　　　）で気持ちがいい。', answer: 'さわやか', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'goo辞書を使って、意味調べをしましょう。<BR>P97。生（い）け捕（ど）る…人や動物などを（　　　）捕（と）らえる。', answer: 'いきたまま', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'goo辞書を使って、意味調べをしましょう。<BR>P97。小屋掛（こやが）け…（　　　）小屋をつくること。', answer: 'かり', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'goo辞書を使って、意味調べをしましょう。<BR>P98。真一文字（まいちもんじ）…（　　　）のようになっすぐなこと。', answer: 'いちのじ', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'goo辞書を使って、意味調べをしましょう。<BR>P98。冷え冷え（ひえびえ）…（　　　）切っているさま。', answer: 'ひえ', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'goo辞書を使って、意味調べをしましょう。<BR>P99。くらます…居（い）場所を（　　　）ようにする。', answer: 'わからない', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'goo辞書を使って、意味調べをしましょう。<BR>P102。不意（ふい）を打つ…（　　　）が予測（よそく）していないときに、事を仕掛（しか）ける。', answer: 'あいて', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''}
];