const mondai = [
    { number: 1, question: '「しゃ」をローマ字で書きましょう。', answer: 'sha', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '「しゅ」をローマ字で書きましょう。', answer: 'shu', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '「しょ」をローマ字で書きましょう。', answer: 'sho', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '「ちゃ」をローマ字で書きましょう。', answer: 'cha', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '「ちゅ」をローマ字で書きましょう。', answer: 'chu', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '「ちょ」をローマ字で書きましょう。', answer: 'cho', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '「にゃ」をローマ字で書きましょう。', answer: 'nya', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: '「にゅ」をローマ字で書きましょう。', answer: 'nyu', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: '「にょ」をローマ字で書きましょう。', answer: 'nyo', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: '「ひゃ」をローマ字で書きましょう。', answer: '', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''}
];