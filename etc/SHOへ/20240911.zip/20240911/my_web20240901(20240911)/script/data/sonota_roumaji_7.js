const mondai = [
    { number: 1, question: '「ひゅ」をローマ字で書きましょう。', answer: '', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '「ひょ」をローマ字で書きましょう。', answer: '', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '「みゃ」をローマ字で書きましょう。', answer: '', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '「みゅ」をローマ字で書きましょう。', answer: '', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '「みょ」をローマ字で書きましょう。', answer: '', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '「りゃ」をローマ字で書きましょう。', answer: '', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '「りゅ」をローマ字で書きましょう。', answer: '', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: '「りょ」をローマ字で書きましょう。', answer: '', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: '「ぎゃ」をローマ字で書きましょう。', answer: '', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: '「ぎゃ」をローマ字で書きましょう。', answer: '', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''}
];