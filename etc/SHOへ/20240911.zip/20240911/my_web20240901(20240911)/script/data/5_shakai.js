const tangen_mei = [
    { number: 1, tangen_mei: '水産業のさかんな地域',fname_ichibu:'suisangyou'},
    { number: 2, tangen_mei: 'これからの食料生産',fname_ichibu:'syokuryou_seisan'},
    { number: 3, tangen_mei: '日本の工業生産と貿易・運輸',fname_ichibu:'kougyou_seisan'},
    { number: 4, tangen_mei: '自動車の生産に励む人々',fname_ichibu:'jidousha'}
];

//単元名をオブジェクト配列にしたため、以下のコードに変更になった。
tangen_mei.forEach(item => {
// 対応するHTML要素を取得
const element = document.getElementById('tangen_mei_' + item.number);
if (element) {
// 要素が存在する場合、その内容を更新
element.textContent = item.tangen_mei;
}
});

//以下の行でうまくいかなかった原因は、「item.number === tangen_data_atai2」としていたため。
//数値と文字列を比較していたため、うまくいかなかった。
//「item.number == tangen_data_atai2」としたら解決した。
let fname_ichibu2 = tangen_mei.find(item => item.number == tangen_data_atai2).fname_ichibu;