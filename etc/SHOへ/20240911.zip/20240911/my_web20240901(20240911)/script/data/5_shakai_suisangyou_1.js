const mondai = [
    { number: 1, question: 'P88。日本の周りの海には、海流や地形のえいきょうで多くの種類の（　　　）が集まります。', answer: 'ぎょかいるい', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P89のエを見て答えましょう。<BR>北からは、親潮と呼ばれる（　　）が流れてきています。', answer: 'かんりゅう', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P90。北海道根室市は、（　　　）の水あげ量が多いことで全国でも有名です。', answer: 'さんま', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P93。せりにかけられたさんまは、漁港の近くにある（　　　）へすぐに運ばれます。', answer: 'かこうこうじょう', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P93。わたしたちが最も気をつかっているのは、（　　　）面です。', answer: 'えいせい', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P95。目的地が遠い場合は、高速道路の料金や燃料代（ねんりょうだい）をおさえるために、（　　　）も利用します。', answer: 'フェリー', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P96。波がおだやかな入り江（え）に、たくさんの大きな（　　　）を設置（せっち）して、成長のぐあいによって魚を分けて育てています。', answer: 'いけす', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P97。えさの成分や育成の様子を記録しておき、いつでも確認（かくにん）できるようにした（　　　）というしくみも取り入れています。', answer: 'トレーサビリティ', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P100。日本をはじめ、水産業のさかんな国々があつまって（　　　い）、漁船の数やとれる量、漁の期間などを決めている。', answer: 'はなしあい', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'P100。世界の漁業生産量が増え、とりすぎによる（　　　）の減少（げんしょう）が進むことが心配されています。', answer: 'すいさんしげん', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''}
];