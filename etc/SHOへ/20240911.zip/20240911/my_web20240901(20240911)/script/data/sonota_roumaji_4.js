const mondai = [
    { number: 1, question: '「ざ」をローマ字で書きましょう。', answer: 'za', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '「じ」をローマ字で書きましょう。', answer: 'zi', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '「ず」をローマ字で書きましょう。', answer: 'zu', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '「ぜ」をローマ字で書きましょう。', answer: 'ze', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '「ぞ」をローマ字で書きましょう。', answer: 'zo', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '「だ」をローマ字で書きましょう。', answer: 'da', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '「じ」をローマ字で書きましょう。', answer: 'di', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: '「づ」をローマ字で書きましょう。', answer: 'du', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: '「で」をローマ字で書きましょう。', answer: 'de', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: '「ど」をローマ字で書きましょう。', answer: 'do', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 11, question: '「ば」をローマ字で書きましょう。', answer: 'ba', image_name: '', etc_1: '', etc_2: '', etc_3: '', etc_4: ''}
];