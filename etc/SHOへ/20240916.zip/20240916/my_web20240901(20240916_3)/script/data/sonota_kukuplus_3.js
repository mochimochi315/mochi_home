const mondai = [
    { number: 1, question: '2×0＝', answer: '0', image_name: '', answer2: '0', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '2×1＝', answer: '2', image_name: '', answer2: '2', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '2×2＝', answer: '4', image_name: '', answer2: '4', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '2×3＝', answer: '6', image_name: '', answer2: '6', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '2×4＝', answer: '8', image_name: '', answer2: '8', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '2×5＝', answer: '10', image_name: '', answer2: '10', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '2×6＝', answer: '12', image_name: '', answer2: '12', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: '2×7＝', answer: '14', image_name: '', answer2: '14', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: '2×8＝', answer: '16', image_name: '', answer2: '16', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: '2×9＝', answer: '18', image_name: '', answer2: '18', etc_2: '', etc_3: '', etc_4: ''},
    { number: 11, question: '2×10＝', answer: '20', image_name: '', answer2: '20', etc_2: '', etc_3: '', etc_4: ''}
];