const mondai = [
    { number: 1, question: '9×1＝', answer: '9', image_name: '', answer2: '9', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '9×2＝', answer: '18', image_name: '', answer2: '18', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '9×3＝', answer: '27', image_name: '', answer2: '27', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '9×4＝', answer: '36', image_name: '', answer2: '36', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '9×5＝', answer: '45', image_name: '', answer2: '45', etc_2: '', etc_3: '', etc_4: ''}
];