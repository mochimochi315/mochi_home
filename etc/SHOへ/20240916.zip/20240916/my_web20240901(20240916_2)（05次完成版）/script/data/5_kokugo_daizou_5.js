const mondai = [
    { number: 1, question: '第1場面（P90～P93）を必ず先に読んでから、次の問題に答えましょう。<BR>P93。つりばりをしかけておいた辺りで、<BR>確かにがんがえをあさったけいせきがあるのに、今日は、（　　　）もはりにかかっていない。7', answer: 'いちわ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '第1場面（P90～P93）を必ず先に読んでから、次の問題に答えましょう。<BR>P93。気をつけてみると、つりばりの糸が、みな、ぴいんと（　　　ある）。', answer: 'ひきのばされてある', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '第1場面（P90～P93）を必ず先に読んでから、次の問題に答えましょう。<BR>P93。これも、あの残雪が仲間を（　　　）してやったにちがいない。', answer: 'しどう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];