const mondai = [
    { number: 1, question: '日本はまわりを（　　　）に囲まれている。', answer: 'うみ', image_name: '', answer2: 'うみ', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P211　自然災害の発生には、国土の（　　　）や気候の特色が大きく関係します。', answer: 'ちけい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P214　上の画像は、（　　　）避難タワーと呼ばれている。', answer: 'つなみ', image_name: '5_shakai_saigai_06.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P216　日本の国土は、プレートの（　　　）にある。', answer: 'きょうかい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P218　上の画像は、（　　　）ダムと呼ばれている。', answer: 'さぼう', image_name: '5_shakai_saigai_05.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P220　自然災害が発生しても、被害をできるだけ減（へ）らそうとする取り組みのことを（　　　）という。', answer: 'げんさい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P219　溶岩（ようがん）などを安全な方向へ流す誘導堤（ゆうどうてい）は、雲仙岳（うんぜんだけ）の（　　　）の後に、つくられた。', answer: 'ふんか', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P217　地震の（　　　）に強くする改修を進める、新幹線の線路の柱', answer: 'ゆれ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P219　高速道路の除雪（じょせつ）作業では、国や（　　　）が協力している。', answer: 'けん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'P218　大きな川の流路や堤防（ていぼう）、遊水池などの整備（せいび）は、（　　　）や都道府県が中心となって進めています。', answer: 'くに', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];