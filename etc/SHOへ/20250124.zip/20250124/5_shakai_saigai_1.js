const mondai = [
    { number: 1, question: '日本海側では、冬には、（　　　）と呼ばれる風がふく。', answer: 'きせつふう', image_name: '', answer2: 'きせつふう', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P210　大量の（　　　）が積もることで、道路の交通や鉄道の運行が大きく乱れる。', answer: 'ゆき', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P211　日本の国土では、たびたび大きな（　　　）が発生してきた。', answer: 'しぜんさいがい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P214　北海道の新ひだか町には、津波からの（　　　）場所の案内が設置（せっち）されている。', answer: 'ひなん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P217　上の画像は、緊急（　　　）速報のしくみを表している。', answer: 'じしん', image_name: '5_shakai_saigai_04.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P220　さまざまな自然災害が起こる日本では、国や都道府県、市町村が協力し、計画的に（　　　）対策を進めている。', answer: 'ぼうさい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P218　上の画像は、「首都圏外郭（しゅとけんがいかく）（　　　）」と呼ばれています。', answer: 'ほうすいろ', image_name: '5_shakai_saigai_02.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P215　田老地区では、（　　　）に強いまちづくりを進めている。', answer: 'つなみ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P217　（　　　）をなくす工事を行うことで、電線を地中にうめ、電柱がたおれる危険をなくすことができる。', answer: 'でんちゅう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'P214　市町村ごとに被害の（ひがい）の想定や避難場所を知らせる標識や（　　　）をつくり、すばやい避難につなげようとしている。（カタカナ）', answer: 'ハザードマップ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];