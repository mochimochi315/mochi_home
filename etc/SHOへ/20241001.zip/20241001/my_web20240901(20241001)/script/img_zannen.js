const img_zannen = ["images/zannen/3001.png", "images/zannen/3002.png", "images/zannen/3003.png",
    "images/zannen/3004.png", "images/zannen/3005.png", "images/zannen/3006.png",
    "images/zannen/3007.png", "images/zannen/3008.png", "images/zannen/3009.png",
    "images/zannen/3010.png", "images/zannen/3011.png", "images/zannen/3012.png",
    "images/zannen/3013.png", "images/zannen/3014.png", "images/zannen/3015.png",
    "images/zannen/3016.png", "images/zannen/3017.png", "images/zannen/3018.png",
    "images/zannen/3019.png", "images/zannen/3020.png", "images/zannen/3021.png",
    "images/zannen/3022.png", "images/zannen/3023.png", "images/zannen/3024.png",
    "images/zannen/3025.png", "images/zannen/3026.png", "images/zannen/3027.png",
    "images/zannen/3028.png"
];
