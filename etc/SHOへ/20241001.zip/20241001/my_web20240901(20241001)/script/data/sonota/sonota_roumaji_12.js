const mondai = [
    { number: 1, question: '「しっきゃく」をローマ字で書きましょう。', answer: 'sikkyaku', image_name: '', answer2: 'sikkyaku', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '「がっきゅう」をローマ字で書きましょう。', answer: 'gakkyuu', image_name: '', answer2: 'gakkyuu', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '「いっちゃく」をローマ字で書きましょう。', answer: 'icchakku', image_name: '', answer2: 'icchakku', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '「にっちゅう」をローマ字で書きましょう。', answer: 'nicchuu', image_name: '', answer2: 'nicchuu', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '「いっちょう」をローマ字で書きましょう。', answer: 'icchou', image_name: '', answer2: 'icchou', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '「はっちゃく」をローマ字で書きましょう。', answer: 'hacchaku', image_name: '', answer2: 'hacchaku', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '「みっちゃく」をローマ字で書きましょう。', answer: 'micchaku', image_name: '', answer2: 'micchaku', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: '「にっちょく」をローマ字で書きましょう。', answer: 'nicchoku', image_name: '', answer2: 'nicchoku', etc_2: '', etc_3: '', etc_4: ''}
];