const mondai = [
    { number: 1, question: '8×1＝', answer: '8', image_name: '', answer2: '8', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '8×2＝', answer: '16', image_name: '', answer2: '16', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '8×3＝', answer: '24', image_name: '', answer2: '24', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '8×4＝', answer: '32', image_name: '', answer2: '32', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '8×5＝', answer: '40', image_name: '', answer2: '40', etc_2: '', etc_3: '', etc_4: ''}
];