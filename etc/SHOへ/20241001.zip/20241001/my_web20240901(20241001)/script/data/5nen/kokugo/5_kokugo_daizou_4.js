const mondai = [
    { number: 1, question: '第1場面（P90～P93）を必ず先に読んでから、次の問題に答えましょう。<BR>P90。残雪というのは、一羽のガンにつけられた（　　　）', answer: 'なまえ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '第1場面（P90～P93）を必ず先に読んでから、次の問題に答えましょう。<BR>P90。今年も残雪は、どこにやって来ましたかは？', answer: 'ぬまち', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '第1場面（P90～P93）を必ず先に読んでから、次の問題に答えましょう。<BR>P90。残雪は、このぬま地に集まるがんの（　　　）らしい。', answer: 'とうりょう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '第1場面（P90～P93）を必ず先に読んでから、次の問題に答えましょう。<BR>P90の6行目の「え」とは、（　　　）のこと。', answer: 'えさ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '第1場面（P90～P93）を必ず先に読んでから、次の問題に答えましょう。<BR>P90。残雪は、（　　　）のとどく所まで決して人間をよせつけなかった。', answer: 'りょうじゅう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '第1場面（P90～P93）を必ず先に読んでから、次の問題に答えましょう。<BR>P91。大造じいさんは、一羽のがんも手に入れることができなくなったので、（　　　）思っていた。', answer: 'いまいましく', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '第1場面（P90～P93）を必ず先に読んでから、次の問題に答えましょう。<BR>P91。じいさんは、一晩（ばん）中かかって、たくさんの（　　　）をしかけておいた。', answer: 'うなぎつりばり', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: '第1場面（P90～P93）を必ず先に読んでから、次の問題に答えましょう。<BR>P91。じいさんは、むねを（　　　）させながら、ぬま地に行った。', answer: 'わくわく', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: '第1場面（P90～P93）を必ず先に読んでから、次の問題に答えましょう。<BR>P92。一羽だけであったが、（　　　）がうまく手に入ったので、じいさんはうれしかった。', answer: 'いきているがん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: '第1場面（P90～P93）を必ず先に読んでから、次の問題に答えましょう。<BR>P92。昨日よりも、もっとたくさんの（　　　）をばらまいておいた。', answer: 'つりばり', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];