const mondai = [
    { number: 1, question: '5×6＝', answer: '30', image_name: '', answer2: '30', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '5×7＝', answer: '35', image_name: '', answer2: '35', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '5×8＝', answer: '40', image_name: '', answer2: '40', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '5×9＝', answer: '45', image_name: '', answer2: '45', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '5×10＝', answer: '50', image_name: '', answer2: '50', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '6×0＝', answer: '0', image_name: '', answer2: '0', etc_2: '', etc_3: '', etc_4: ''}
];