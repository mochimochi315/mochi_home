const mondai = [
    { number: 1, question: '「がっこう」をローマ字で書きましょう。', answer: 'gakkou', image_name: '', answer2: 'gakkou', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '「ざっし」をローマ字で書きましょう。', answer: 'zassi', image_name: '', answer2: 'zassi', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '「かっぱ」をローマ字で書きましょう。', answer: 'kappa', image_name: '', answer2: 'kappa', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '「いっぽん」をローマ字で書きましょう。', answer: 'ippon', image_name: '', answer2: 'ippon', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '「きっぷ」をローマ字で書きましょう。', answer: 'kippu', image_name: '', answer2: 'kippu', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '「けっこん」をローマ字で書きましょう。', answer: 'kekkon', image_name: '', answer2: 'kekkon', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '「しっぱい」をローマ字で書きましょう。', answer: 'sippai', image_name: '', answer2: 'sippai', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: '「ねったい」をローマ字で書きましょう。', answer: 'nettai', image_name: '', answer2: 'nettai', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: '「ひっこし」をローマ字で書きましょう。', answer: 'hikkosi', image_name: '', answer2: 'hikkosi', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: '「やっぱり」をローマ字で書きましょう。', answer: 'yappari', image_name: '', answer2: 'yappari', etc_2: '', etc_3: '', etc_4: ''},
    { number: 11, question: '「おっと」をローマ字で書きましょう。', answer: 'otto', image_name: '', answer2: 'otto', etc_2: '', etc_3: '', etc_4: ''},
    { number: 12, question: '「いっしょ」をローマ字で書きましょう。', answer: 'issho', image_name: '', answer2: 'issho', etc_2: '', etc_3: '', etc_4: ''},
    { number: 13, question: '「じっか」をローマ字で書きましょう。', answer: 'jikka', image_name: '', answer2: 'jikka', etc_2: '', etc_3: '', etc_4: ''},
    { number: 14, question: '「きっさてん」をローマ字で書きましょう。', answer: 'kissaten', image_name: '', answer2: 'kissaten', etc_2: '', etc_3: '', etc_4: ''}
];