const mondai = [
    { number: 1, question: 'Bの部分は、（　　　）といいます。', answer: 'がく', image_name: '5-rika-1-15.png', answer2: 'がく', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'Cの部分は、（　　　）といいます。', answer: 'はなびら', image_name: '5-rika-1-16.png', answer2: 'はなびら', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '（　　　）の中のめしべの先', answer: 'つぼみ', image_name: '5-rika-1-17.png', answer2: 'つぼみ', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '（　　　）花のめしべの先', answer: 'さいている', image_name: '5-rika-1-18.png', answer2: 'さいている', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '（　　　）の先', answer: 'おしべ', image_name: '5-rika-1-19.png', answer2: 'おしべ', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '（　　　）の花粉（カタカナで）', answer: 'ヘチマ', image_name: '5-rika-1-20.png', answer2: 'ヘチマ', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '（　　　）の花粉（カタカナで）', answer: 'アサガオ', image_name: '5-rika-1-21.png', answer2: 'アサガオ', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'Aの部分は、（　　　）といいます。', answer: 'めしべ', image_name: '5-rika-1-22.png', answer2: 'めしべ', etc_2: '', etc_3: '', etc_4: ''}
];