const mondai = [
    { number: 1, question: '「きって」をローマ字で書きましょう。', answer: 'kitte', image_name: '', answer2: 'kitte', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '「みっつ」をローマ字で書きましょう。', answer: 'mittsu', image_name: '', answer2: 'mittsu', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '「てっきょう」をローマ字で書きましょう。', answer: 'tekkyou', image_name: '', answer2: 'tekkyou', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '「せっけん」をローマ字で書きましょう。', answer: 'sekken', image_name: '', answer2: 'sekken', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '「ざっそう」をローマ字で書きましょう。', answer: 'zassou', image_name: '', answer2: 'zassou', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '「はっぱ」をローマ字で書きましょう。', answer: 'happa', image_name: '', answer2: 'happa', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '「きゃっかん」をローマ字で書きましょう。', answer: 'kyakkan', image_name: '', answer2: 'kyakkan', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: '「きょっかい」をローマ字で書きましょう。', answer: 'kyokkai', image_name: '', answer2: 'kyokkai', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: '「ちょっかく」をローマ字で書きましょう。', answer: 'chokkaku', image_name: '', answer2: 'chokkaku', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: '「ひゃっかじてん」をローマ字で書きましょう。', answer: 'hyakkajiten', image_name: '', answer2: 'hyakkajiten', etc_2: '', etc_3: '', etc_4: ''},
    { number: 11, question: '「ひゃっきん」をローマ字で書きましょう。', answer: 'hyakkin', image_name: '', answer2: 'hyakkin', etc_2: '', etc_3: '', etc_4: ''},
    { number: 12, question: '「いっきゅう」をローマ字で書きましょう。', answer: ' ikkyuu', image_name: '', answer2: ' ikkyuu', etc_2: '', etc_3: '', etc_4: ''},
    { number: 13, question: '「ちょっきゅう」をローマ字で書きましょう。', answer: 'chokkyuu', image_name: '', answer2: 'chokkyuu', etc_2: '', etc_3: '', etc_4: ''}
];