//このファイルの中に、「'use strict';」を記述するとエラーになる。

let img_question = ["images/question/1001.png", "images/question/1002.png", "images/question/1003.png", "images/question/1004.png",
    "images/question/1005.png", "images/question/1006.png", "images/question/1007.png", "images/question/1008.png",
    "images/question/1009.png", "images/question/1010.png", "images/question/1011.png", "images/question/1012.png",
    "images/question/1013.png", "images/question/1014.png", "images/question/1015.png", "images/question/1016.png",
    "images/question/1017.png", "images/question/1018.png", "images/question/1019.png", "images/question/1020.png",
    "images/question/1021.png", "images/question/1022.png", "images/question/1023.png", "images/question/1024.png",
    "images/question/1025.png", "images/question/1026.png", "images/question/1027.png", "images/question/1028.png",
    "images/question/1029.png", "images/question/1030.png", "images/question/1031.png", "images/question/1032.png",
    "images/question/1033.png", "images/question/1034.png", "images/question/1035.png", "images/question/1036.png",
    "images/question/1037.png", "images/question/1038.png", "images/question/1039.png"
];
