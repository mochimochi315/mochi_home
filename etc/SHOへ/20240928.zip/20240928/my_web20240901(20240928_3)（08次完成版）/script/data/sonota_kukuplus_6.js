const mondai = [
    { number: 1, question: '4×1＝', answer: '4', image_name: '', answer2: '4', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '4×2＝', answer: '8', image_name: '', answer2: '8', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '4×3＝', answer: '12', image_name: '', answer2: '12', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '4×4＝', answer: '16', image_name: '', answer2: '16', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '4×5＝', answer: '20', image_name: '', answer2: '20', etc_2: '', etc_3: '', etc_4: ''}
];