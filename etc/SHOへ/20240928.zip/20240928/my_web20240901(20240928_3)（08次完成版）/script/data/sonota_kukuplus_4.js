const mondai = [
    { number: 1, question: '3×1＝', answer: '3', image_name: '', answer2: '3', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '3×2＝', answer: '6', image_name: '', answer2: '6', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '3×3＝', answer: '9', image_name: '', answer2: '9', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '3×4＝', answer: '12', image_name: '', answer2: '12', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '3×5＝', answer: '15', image_name: '', answer2: '15', etc_2: '', etc_3: '', etc_4: ''}
];