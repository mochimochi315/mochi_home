const mondai = [
    { number: 1, question: 'これは、ヘチマです。この花の名前は？', answer: 'めばな', image_name: '5-rika-1-01.png', answer2: 'めばな', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'これは、ヘチマです。この花の名前は？', answer: 'おばな', image_name: '5-rika-1-02.png', answer2: 'おばな', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'Aの部分は、何といいますか？', answer: 'めしべ', image_name: '5-rika-1-03.png', answer2: 'めしべ', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'Bの部分は、何といいますか？', answer: 'おしべ', image_name: '5-rika-1-04.png', answer2: 'おしべ', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'これはどちらの花ですか？（めしべ、おしべ）', answer: 'めしべ', image_name: '5-rika-1-05.png', answer2: 'めしべ', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'これはどちらの花ですか？（めしべ、おしべ）', answer: 'おしべ', image_name: '5-rika-1-06.png', answer2: 'おしべ', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'Aの部分は、何といいますか？（すべてひらがなで）', answer: 'せつがんれんず', image_name: '5-rika-1-07.png', answer2: 'せつがんれんず', etc_2: '', etc_3: '', etc_4: ''}
];