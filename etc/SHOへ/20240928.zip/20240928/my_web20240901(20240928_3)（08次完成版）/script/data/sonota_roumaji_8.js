const mondai = [
    { number: 1, question: '「ぎょ」をローマ字で書きましょう。', answer: 'gyo', image_name: '', answer2: 'gyo', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '「じゃ」をローマ字で書きましょう。', answer: 'ja', image_name: '', answer2: 'ja', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '「じゅ」をローマ字で書きましょう。', answer: 'ju', image_name: '', answer2: 'ju', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '「じょ」をローマ字で書きましょう。', answer: 'jo', image_name: '', answer2: 'jo', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '「ぢゃ」をローマ字で書きましょう。', answer: 'dya', image_name: '', answer2: 'dya', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '「ぢゅ」をローマ字で書きましょう。', answer: 'dyu', image_name: '', answer2: 'dyu', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '「ぢょ」をローマ字で書きましょう。', answer: 'dyo', image_name: '', answer2: 'dyo', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: '「びゃ」をローマ字で書きましょう。', answer: 'bya', image_name: '', answer2: 'bya', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: '「びゅ」をローマ字で書きましょう。', answer: 'byu', image_name: '', answer2: 'byu', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: '「びょ」をローマ字で書きましょう。', answer: 'byo', image_name: '', answer2: 'byo', etc_2: '', etc_3: '', etc_4: ''}
];