const mondai = [
    { number: 1, question: '8×6＝', answer: '48', image_name: '', answer2: '48', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '8×7＝', answer: '56', image_name: '', answer2: '56', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '8×8＝', answer: '64', image_name: '', answer2: '64', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '8×9＝', answer: '72', image_name: '', answer2: '72', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '8×10＝', answer: '80', image_name: '', answer2: '80', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '9×0＝', answer: '0', image_name: '', answer2: '0', etc_2: '', etc_3: '', etc_4: ''}
];