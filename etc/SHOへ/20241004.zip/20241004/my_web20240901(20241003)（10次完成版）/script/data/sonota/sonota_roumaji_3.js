const mondai = [
    { number: 1, question: '「る」をローマ字で書きましょう。', answer: 'ru', image_name: '', answer2: 'ru', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '「れ」をローマ字で書きましょう。', answer: 're', image_name: '', answer2: 're', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '「ろ」をローマ字で書きましょう。', answer: 'ro', image_name: '', answer2: 'ro', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '「わ」をローマ字で書きましょう。', answer: 'wa', image_name: '', answer2: 'wa', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '「を」をローマ字で書きましょう。', answer: 'wo', image_name: '', answer2: 'wo', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '「ん」をローマ字で書きましょう。', answer: 'nn', image_name: '', answer2: 'nn', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '「が」をローマ字で書きましょう。', answer: 'ga', image_name: '', answer2: 'ga', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: '「ぎ」をローマ字で書きましょう。', answer: 'gi', image_name: '', answer2: 'gi', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: '「ぐ」をローマ字で書きましょう。', answer: 'gu', image_name: '', answer2: 'gu', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: '「げ」をローマ字で書きましょう。', answer: 'ge', image_name: '', answer2: 'ge', etc_2: '', etc_3: '', etc_4: ''},
    { number: 11, question: '「ご」をローマ字で書きましょう。', answer: 'go', image_name: '', answer2: 'go', etc_2: '', etc_3: '', etc_4: ''}
];