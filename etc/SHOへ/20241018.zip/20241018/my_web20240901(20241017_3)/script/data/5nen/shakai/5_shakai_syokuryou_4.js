const mondai = [
    { number: 1, question: 'P114。輸入するチーズにかける税金が引き下げられたため、より（　　　）値段で、チーズが買えるようになった。', answer: 'やすい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P115。フードマイレージとは、食料を産地から消費地に運ぶときに使う（　　　）の量を表す数。（答えはカタカナ）', answer: 'エネルギー', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P115。日本などに輸出するえびを育てるために、生き物のすみかとなっている（　　　）の林を切り、養殖池（ようしょくち）をつくっている国がある。（答えは、カタカナ）', answer: 'マングローブ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P116。鹿児島県では、輸出向けの（　　）の加工も行っている。', answer: 'ぶり', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P116。スーパーマーケットを営む（いとなむ）会社では、野菜をつくる（　　　）と契約を結んでいる。', answer: 'のうじょう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P117。ブランドぶた肉では、味や安全性、育て方にちがいをつけて（　　　）を高めている。', answer: 'かち', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P118。国内の食料生産を発展させていくためには、値段が安いからといって、（　　　）食材をえらびすぎない。', answer: 'ゆにゅうした', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P118。国内の食料生産を発展させていくために、地元の直売所をもっと利用して、（　　　）食材をもっと食べる。', answer: 'じもとの', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P118。国内の食料生産を発展させていくために、（　　　）の消費者に向けて、輸出を増やす。', answer: 'がいこく', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'P118。国内の食料生産を発展させていくために、周りの農家や店と協力して、新しい（　　　）野菜をつくって売り出す。（答えは、カタカナ）', answer: 'ブランド', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];