const mondai = [
    { number: 1, question: 'Bの部分は、何といいますか？（すべてひらがなで）', answer: 'たいぶつれんず', image_name: '5_rika_hana_kara_mie_08.png', answer2: 'たいぶつれんず', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'Aの部分は、何といいますか？', answer: 'ちょうせつねじ', image_name: '5_rika_hana_kara_mie_09.png', answer2: 'ちょうせつねじ', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'Bの部分は、何といいますか？', answer: 'はんしゃきょう', image_name: '5_rika_hana_kara_mie_10.png', answer2: 'はんしゃきょう', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'プレパラートを（　　　）に動かす。', answer: 'ひだりした', image_name: '5_rika_hana_kara_mie_11.png', answer2: 'ひだりした', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'まず（　　い）倍率で、見るものが真ん中になるようにしておく。', answer: 'ひくい', image_name: '5_rika_hana_kara_mie_12.png', answer2: 'ひくい', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'はっきり見えなければ（　　　）を少しずつ回して、ピントを合わせる。', answer: 'ちょうせつねじ', image_name: '5_rika_hana_kara_mie_13.png', answer2: 'ちょうせつねじ', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'Aの部分は、（　　　）になる部分です。', answer: 'み', image_name: '5_rika_hana_kara_mie_14.png', answer2: 'み', etc_2: '', etc_3: '', etc_4: ''}
];