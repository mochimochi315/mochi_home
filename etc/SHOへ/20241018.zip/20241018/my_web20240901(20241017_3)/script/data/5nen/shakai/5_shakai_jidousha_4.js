const mondai = [
    { number: 1, question: 'P131。働きやすい環境を整えることが、ミスを防（ふせ）ぎ、（　　　）にもつながります。', answer: 'こうりつのよいせいさん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P132。シートは、自動車工場の（　　　）にある関連工場で生産されています。', answer: 'かんれんこうじょう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P132。シート工場の検査では、少しでもしわやきずがあれば、すぐに（　　　）なくてはなりません。', answer: 'とりかえ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P133。１台の自動車を生産するためには、２万から３万個ほどの（　　　）が必要になります。', answer: 'ぶひん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P134。自動車工場から、遠い地域に運ばれる自動車は、工場のそばの港で、専用の（　　　）に積みこまれます。', answer: 'ふね', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P135。集めた（　　　）をもとに、どのような自動車にしたいか、どの機能を取り入れるかを考えていきます。（カタカナ）', answer: 'ニーズ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P137。駐車を助ける機能がついた車は、駐車場に駐車する時に（　　　）の操作（そうさ）などを自動でしてくれる。（カタカナ）', answer: 'ハンドル', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P138。回転するシートがついた車は、（　　　）やベビーカーを使う人でも乗り降りがしやすくなっている。', answer: 'くるまいす', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P138。（　　　）自動車は、バッテリーの電気で動く自動車です。環境にやさしい自動車といえます。', answer: 'でんき', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'P140。これからの自動車づくりでは、環境に（　　　）自動車づくりが大切になってくる。', answer: 'やさしい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];