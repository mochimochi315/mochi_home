const mondai = [
    { number: 1, question: 'Bの部分は、（　　　）といいます。', answer: 'がく', image_name: '5_rika_hana_kara_mie_15.png', answer2: 'がく', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'Cの部分は、（　　　）といいます。', answer: 'はなびら', image_name: '5_rika_hana_kara_mie_16.png', answer2: 'はなびら', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '（　　　）の中のめしべの先', answer: 'つぼみ', image_name: '5_rika_hana_kara_mie_17.png', answer2: 'つぼみ', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '（　　　）花のめしべの先', answer: 'さいている', image_name: '5_rika_hana_kara_mie_18.png', answer2: 'さいている', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '（　　　）の先', answer: 'おしべ', image_name: '5_rika_hana_kara_mie_19.png', answer2: 'おしべ', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '（　　　）の花粉（カタカナで）', answer: 'ヘチマ', image_name: '5_rika_hana_kara_mie_20.png', answer2: 'ヘチマ', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '（　　　）の花粉（カタカナで）', answer: 'アサガオ', image_name: '5_rika_hana_kara_mie_21.png', answer2: 'アサガオ', etc_2: '', etc_3: '', etc_4: ''}
];