const mondai = [
    { number: 1, question: 'ヒトは、（　　　らん）から育っている。', answer: 'じゅせいらん', image_name: '', answer2: 'じゅせいらん', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'メダカの受精卵は、直径約1㎜です。ヒトの受精卵は、メダカの受精卵よりも大きいですか。小さいですか。', answer: 'ちいさい', image_name: '', answer2: 'ちいさい', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P94。羊水には、外部からの力をやわらげ、（　　　）を守るはたらきがある。', answer: 'こども', image_name: '', answer2: 'こども', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P94。「たいばん」と「へそのお」を通して、子どもから母親に（　　　）を渡す。', answer: 'いらないもの', image_name: '', answer2: 'いらないもの', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P96。受精後、ヒトの子どもが生まれるまでの期間は、約（　　　）週間。（半角数字で）', answer: '38', image_name: '', answer2: '38', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P90。これは、母親の体内での（　　　らん）の写真です。', answer: 'じゅせいらん', image_name: '5_rika_hito_no_tanjyou_07.png', answer2: 'じゅせいらん', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P96。子どもは、自分で食べ物を食べるのではなく、（　　　）から、養分を受け取っている。', answer: 'ははおや', image_name: '', answer2: 'ははおや', etc_2: '', etc_3: '', etc_4: ''}
];