const mondai = [
    { number: 1, question: 'P106。水の流れによって、地面（土）がけずられるのは、ABのどちらですか。（半角英字）', answer: 'A', image_name: '5_rika_nagareru_mizu_03.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P106。流れる水が土を運ぶはたらきを（　　　）という。', answer: 'うんぱん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P108。川の内側は、ABのどちらですか。（半角英字）', answer: 'B', image_name: '5_rika_nagareru_mizu_08.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P110。次の地形が見られるのは、「山の中」ですか、「平地（へいち）」ですか。', answer: 'へいち', image_name: '5_rika_nagareru_mizu_18.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P111。平地や海の近くでは、（　　　く）て丸い石やすなが多く見られる。', answer: 'ちいさく', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P115。大雨で川の水の量が増えると、流れる水の土などをはこぶはたらきの大きさは（大きくなる、かわらない、小さくなる）。', answer: 'おおきくなる', image_name: '5_rika_nagareru_mizu_14.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P106。流れる水には、（　　　）をけずったりするはたらきがある。', answer: 'じめん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P106。地面が（　　　られている）ところでは、流れが速い。', answer: 'けずられている', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P108。流れのはやい外側は、けずられて（　　　）になっている。', answer: 'がけ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'P111。山の中では、（　　　）て角ばった石が多くみられる。', answer: 'おおきく', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];