const mondai = [
    { number: 1, question: 'P106。運ばれてきた土が積もるのは、ABのどちらですか。（半角英字）', answer: 'B', image_name: '5_rika_nagareru_mizu_02.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P106。流れる水が地面をけずるはたらきを（　　　）という。', answer: 'しんしょく', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P106。流れる水が土などを積もらせるはたらきを（　　　）という。', answer: 'たいせき', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P108。川の内側は、水の流れが（　　か）。', answer: 'ゆるやか', image_name: '5_rika_nagareru_mizu_12.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P108。川の外側は、ABのどちらですか。（半角英字）', answer: 'A', image_name: '5_rika_nagareru_mizu_09.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P108。川の外側は、川の深さは（　　い）。', answer: 'ふかい', image_name: '5_rika_nagareru_mizu_11.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P110。次の地形が見られるのは、「山の中」ですか、「平地（へいち）」ですか。', answer: 'やまのなか', image_name: '5_rika_nagareru_mizu_19.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P111。かたむきが急な山の中では、川の流れは、（　　い）。', answer: 'はやい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P114。流れる水の量が多くなると、より多くの（　　　）が運ばれる。', answer: 'つち', image_name: '5_rika_nagareru_mizu_07.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'P117。（　　　）は、石やすなの運ぱんや水の流れの勢いを弱くすることができる。（全部ひらがなで）', answer: 'さぼうだむ', image_name: '5_rika_nagareru_mizu_16.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];