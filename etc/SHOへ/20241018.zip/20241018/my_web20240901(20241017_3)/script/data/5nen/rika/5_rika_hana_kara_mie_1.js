const mondai = [
    { number: 1, question: 'これは、ヘチマです。この花の名前は？', answer: 'めばな', image_name: '5_rika_hana_kara_mie_01.png', answer2: 'めばな', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'これは、ヘチマです。この花の名前は？', answer: 'おばな', image_name: '5_rika_hana_kara_mie_02.png', answer2: 'おばな', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'Aの部分は、何といいますか？', answer: 'めしべ', image_name: '5_rika_hana_kara_mie_03.png', answer2: 'めしべ', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'Bの部分は、何といいますか？', answer: 'おしべ', image_name: '5_rika_hana_kara_mie_04.png', answer2: 'おしべ', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'これはどちらの花ですか？（めしべ、おしべ）', answer: 'めしべ', image_name: '5_rika_hana_kara_mie_05.png', answer2: 'めしべ', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'これはどちらの花ですか？（めしべ、おしべ）', answer: 'おしべ', image_name: '5_rika_hana_kara_mie_06.png', answer2: 'おしべ', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'Aの部分は、何といいますか？（すべてひらがなで）', answer: 'せつがんれんず', image_name: '5_rika_hana_kara_mie_07.png', answer2: 'せつがんれんず', etc_2: '', etc_3: '', etc_4: ''}
];