const mondai = [
    { number: 1, question: 'これは、ヒトの（　　　）の画像です。', answer: 'せいし', image_name: '5_rika_hito_no_tanjyou_09.png', answer2: 'せいし', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P92。約10週のヒトの子どもの身長は、約（　　　）㎝です。（半角数字で）', answer: '9', image_name: '', answer2: '9', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P93。約26週のヒトの子どもの身長は、約（　　　）㎝です。（半角数字で）', answer: '35', image_name: '', answer2: '35', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P93。約34週のヒトの子どもの身長は、約（　　　）㎝です。（半角数字で）', answer: '45', image_name: '', answer2: '45', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P92。約10週のヒトの子どもの体重は、約（　　　）gです。（半角数字で）', answer: '20', image_name: '', answer2: '20', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P93。約26週のヒトの子どもの体重は、約（　　　）gです。（半角数字で）', answer: '1000', image_name: '', answer2: '1000', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P93。約34週のヒトの子どもの体重は、約（　　　）gです。（半角数字で）', answer: '2000', image_name: '', answer2: '2000', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P99。周りの人に、おなかに赤ちゃんがいることを示すためのマークのことを（　　　）という。（カタカナで）', answer: 'マタニティマーク', image_name: '', answer2: 'マタニティマーク', etc_2: '', etc_3: '', etc_4: ''}
];