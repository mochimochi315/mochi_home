const mondai = [
    { number: 1, question: 'P112。日本は、外国と比べると、食料自給率が（　　　い）。', answer: 'ひくい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P113。交通の発達や冷凍技術の進歩によって、遠い（　　　）から食材を運べるようになった。', answer: 'がいこく', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P113。交通の発達や冷凍技術の進歩によって、（　　　）な食材を運べるようになった。', answer: 'しんせん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P114。限られた国からの輸入にたよりすぎると、それらの国で事故や災害があった場合に、食生活が（　　　）になる心配がある。', answer: 'ふあんてい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P116。生産からはん売までをすべて管理することで、（　　　）作物を安く確実にとどけることができる。', answer: 'しつのよい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P117。形や見ばえの悪い野菜を売ることで、すてられる（　　　う）の量を減らしている。', answer: 'しょくりょう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P117。（　　　）では、地元でとれた農産物や、それらを材料にした加工品などもうっています。', answer: 'ちょくばいじょ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];