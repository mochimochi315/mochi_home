const mondai = [
    { number: 1, question: '6×6＝', answer: '36', image_name: '', answer2: '36', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '6×7＝', answer: '42', image_name: '', answer2: '42', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '6×8＝', answer: '48', image_name: '', answer2: '48', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '6×9＝', answer: '54', image_name: '', answer2: '54', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '6×10＝', answer: '60', image_name: '', answer2: '60', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '7×0＝', answer: '0', image_name: '', answer2: '0', etc_2: '', etc_3: '', etc_4: ''}
];