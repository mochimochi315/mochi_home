const mondai = [
    { number: 1, question: 'P93。大造じいさんは、なせ感嘆（かんたん）の声をもらしてしまったのですか。<BR>がんは、鳥類の中では、あまりりこうではないのに、（　　　）をもっていたから。', answer: 'たいしたちえ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P94。がんにとって、なぜそこのぬま地がお気に入りの場所になったのですか。<BR>（　　　）が四、五日も続いたから。', answer: 'おもわぬごちそう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P95。なぜ、じいさんは、猟銃（りょうじゅう）を打たずに、もう少ししんぼうしたのですか。<BR>猟銃の（　　　）がまだとどかないから。', answer: 'たま', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P96。残雪は、なぜ、ぐっと急角度に方向を変えたのですか。<BR>「（　　　）には、近づかぬがよいぞ。」とかれの本能がそう感じたから。', answer: 'ようすのかわったところ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P96。じいさんがつかまえたがんは、どこにいましたか。', answer: 'にわとりごや', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P96。じいさんは、つかまえたがんを何年間育てましたか。', answer: 'にねんかん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P97。じいさんは、おとりのがんをつかって、何をとらえてやろうとおもったのですか。', answer: 'ざんせつのなかま', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P98。じいさんは、なぜしばらく目をつぶったのですか。<BR>心の（　　　）のを待つため。', answer: 'おちつく', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P99。はやぶさがやってきた時に、がんの群れは、どのように飛び去っていきましたか。<BR>実にすばやい動作で、（　　　ながら）飛び去っていった。', answer: 'はやぶさのめをくらましながら', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'P99。大造じいさんの（　　　）が飛びおくれた。', answer: 'おとりのがん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];