const mondai = [
    { number: 1, question: 'P112。食料自給率とは、国内で消費された食料のうち、どれだけ国内で（　　　）されたかを表す割合のこと。', answer: 'せいさん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P112。天ぷらそばに使われる食料のほとんどは、（　　　）した食材を使っている。', answer: 'ゆにゅう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P113。2020年度の野菜の生産量は、1980年と比べて、（　　　た）。', answer: 'へった', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P113。野菜、魚、肉、果物などは、1980年に比べて、国内での生産量が（増えている、減っている）。', answer: 'へっている', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P114。にんじん、ねぎ、かぼちゃ、牛肉は、輸入のほうが値段が（　　　）。', answer: 'やすい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P116。野菜工場では、室内で光や温度を調節して、（　　　）に生産します。', answer: 'けいかくてき', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P117。形や見ばえが悪い野菜も、味や（　　　）に問題がなければ、むだにせずに売っている。', answer: 'あんぜんせい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P117。日本の食料生産のことを考えると、（　　　）にばかりたよらず、国内で生産された農作物を食べることが大切になっている。', answer: 'ゆにゅう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];