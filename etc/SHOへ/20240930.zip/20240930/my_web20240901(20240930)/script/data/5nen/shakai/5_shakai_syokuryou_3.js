const mondai = [
    { number: 1, question: 'P113。日本の場合は、食糧自給率が一番高いのは（　　　）である。', answer: 'こめ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P114。世界各地からの輸入によって、（　　　かつ）を豊かにすることができる。', answer: 'しょくせいかつ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P114。輸入された食材には、（　　　）が行われ、安全性を確かめている。', answer: 'けんさ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P116。生産からはん売までをすべて管理することで、生産者の人たちにとっても、（　　　た）生産ができる。', answer: 'あんていした', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P117。売れ残りや、すてられたパンを家畜（かちく）のえさにすることで、すてられる（　　　う）の量を減らしている。', answer: 'しょくりょう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P117。地元でとれた食材を地元で消費する（　　　）によって、日本の食料自給率を上げることができる。', answer: 'ちさんちしょう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P117。地元でとれた野菜を直売所で（　る）ことで、日本の食料自給率を上げている。', answer: 'うる', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];