//このファイルは、「test02.htmlファイル」、「shutsudai.html」ファイルからの送信で利用している。

function doPost(e) {
  
  var data = JSON.parse(e.postData.contents);

  //送信されてきた教科名（シート名）、ユーザー名、単元名を取得する。
  var sheetName=data.kyouka;
  var user=data.name;
  var unit=data.tangen;
  
  // スプレッドシートIDを指定して取得
  var spreadsheetId = '14LYFJ6AxunJrv1M4wUh6kH5pHmkBve1aVoL4V-lGUB4';
  var spreadsheet = SpreadsheetApp.openById(spreadsheetId);
  var sheet = spreadsheet.getSheetByName(sheetName);
  
  // 列番号を取得（unit列）
  var columnNumber = getColumnNumber(sheet, unit);  // unitを渡す

  // 行番号を取得（user名で検索）
  var rowNumber = search_gyou(sheet, user);  // userを渡す
 
  // エラーハンドリング
  if (rowNumber === -1) {
    Logger.log(user + " が見つかりませんでした。処理を中断します。");
    return;
  }
  
  if (columnNumber === -1) {
    Logger.log(unit + " 列が見つかりませんでした。処理を中断します。");
    return;
  }

  // 指定された行・列に「OK」を書き込む
  sheet.getRange(rowNumber, columnNumber).setValue("OK");  
}



function search_gyou(sheet, user) {
  // A列の全データを取得（データのない行も含む）
  var columnData = sheet.getRange("A:A").getValues();
  
  // 最終行を取得
  var lastRow = sheet.getLastRow();  // 最終行を取得

  // 2行目から最終行まで "user" を検索
  for (var row = 2; row <= lastRow; row++) {
    if (columnData[row - 1][0] === user) {  // user名で検索
      Logger.log(user + " は " + row + " 行目に見つかりました。");
      return row;  // 見つかった行番号を返す
    }
  }
 
  // 見つからなかった場合
  Logger.log(user + " は見つかりませんでした。");
  return -1;  // 見つからなかった場合は -1 を返す
  }


function getColumnNumber(sheet, unit) {
  // 1行目のヘッダーを取得。データが入力されている最終列までを取得する。
  var headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  
  // 検索する列名（unit列）
  var targetHeader = unit;
  
  // ループで列名を検索し、列番号を返す
  for (var column = 0; column < headers.length; column++) {
    if (headers[column] === targetHeader) {
      Logger.log(targetHeader + " は " + (column + 1) + " 列目にあります。");
      return column + 1;  // 列番号を返す
    }
  }

  // 見つからなかった場合
  Logger.log(targetHeader + " は見つかりませんでした。");
  return -1;  // 見つからなかった場合のエラーハンドリング
}

