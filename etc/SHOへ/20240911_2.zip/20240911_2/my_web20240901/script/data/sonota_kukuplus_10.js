const mondai = [
    { number: 1, question: '6×1＝', answer: '6', image_name: '', answer2: '6', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '6×2＝', answer: '12', image_name: '', answer2: '12', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '6×3＝', answer: '18', image_name: '', answer2: '18', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '6×4＝', answer: '24', image_name: '', answer2: '24', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '6×5＝', answer: '30', image_name: '', answer2: '30', etc_2: '', etc_3: '', etc_4: ''}
];