const mondai = [
    { number: 1, question: 'P138のコを見て答えましょう。リフトつきの自動車は、（　　　）いすに乗ったまま、車に乗ることができる。', answer: 'くるま', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P140。これからの自動車づくりでは、だれでも（　　　）車づくりをめざしていくことが大切。', answer: 'つかいやすい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P131。ミスを防ぐためのしくみがいろいろなところにあった。だから、自動車を（　　　）に、たくさん生産できる。', answer: 'せいかく', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P133。さまざまな種類の自動車を生産する組み立て工場に、必要な部品をとどける（　　　）・イン・タイム方式は、多くの関連工場の協力によって成り立っている。（カタカナ）', answer: 'ジャスト', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P134。船で各地の港に運ばれた自動車は、そこからはん売店まで、専用の（　　　）で運ばれます。（カタカナ）', answer: 'キャリアカー', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P135。多くの自動車工場は、（　　　）の近くや広い道路の近くに建っています。', answer: 'みなと', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P135。工場で使う大量の部品や原材料は、港や（　　　）を通じて運びこんでいる。', answer: 'こうそくどうろ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P135。自動車を運ぶ専用船は、国内輸送用で1000台、海外輸送用で、（　　　）台もの自動車を一度に運べる。（半角数字）', answer: '8000', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P138。（　　　）自動車は、水素と空気中の酸素から電気をつくり、走る自動車です。', answer: 'ねんりょうでんち', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'P139。自動車工場では、だれもが（　　　）工場をめざしている。', answer: 'はたらきやすい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];