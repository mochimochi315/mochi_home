const mondai = [
    { number: 1, question: 'これは、受精後約26週目の図です。<BR>活発に（　　　）ようになります。', answer: 'うごく', image_name: '5_rika_hito_no_tanjyou_02.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'これは、ヒトの受精卵です。受精卵の大きさは約（　　　）㎜です。（半角数字で）', answer: '0.14', image_name: '5_rika_hito_no_tanjyou_03.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '女性の体内では、卵（　　　）がつくられる。', answer: 'らんし', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '子どもが育つところを、何といいますか。', answer: 'しきゅう', image_name: '5_rika_hito_no_tanjyou_04.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P94。「たいばん」と「へそのお」を通して、母親から（　　　）などをもらう。', answer: 'ようぶん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P95。生まれたばかりのヒトの子どもの体重は、約（　　　）gです。（半角数字で）', answer: '3000', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '母親と子どもは、（　　　お）でつながっている。', answer: 'へそのお', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];