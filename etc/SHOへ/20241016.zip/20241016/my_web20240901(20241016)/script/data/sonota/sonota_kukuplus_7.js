const mondai = [
    { number: 1, question: '4×6＝', answer: '24', image_name: '', answer2: '24', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '4×7＝', answer: '28', image_name: '', answer2: '28', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '4×8＝', answer: '32', image_name: '', answer2: '32', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '4×9＝', answer: '36', image_name: '', answer2: '36', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '4×10＝', answer: '40', image_name: '', answer2: '40', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '5×0＝', answer: '0', image_name: '', answer2: '0', etc_2: '', etc_3: '', etc_4: ''}
];