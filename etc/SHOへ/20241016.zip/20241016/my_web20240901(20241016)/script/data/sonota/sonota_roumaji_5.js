const mondai = [
    { number: 1, question: '「び」をローマ字で書きましょう。', answer: 'bi', image_name: '', answer2: 'bi', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '「ぶ」をローマ字で書きましょう。', answer: 'bu', image_name: '', answer2: 'bu', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '「べ」をローマ字で書きましょう。', answer: 'be', image_name: '', answer2: 'be', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '「ぼ」をローマ字で書きましょう。', answer: 'bo', image_name: '', answer2: 'bo', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '「ぱ」をローマ字で書きましょう。', answer: 'pa', image_name: '', answer2: 'pa', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '「ぴ」をローマ字で書きましょう。', answer: 'pi', image_name: '', answer2: 'pi', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '「ぷ」をローマ字で書きましょう。', answer: 'pu', image_name: '', answer2: 'pu', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: '「ぺ」をローマ字で書きましょう。', answer: 'pe', image_name: '', answer2: 'pe', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: '「ぽ」をローマ字で書きましょう。', answer: 'po', image_name: '', answer2: 'po', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: '「きゃ」をローマ字で書きましょう。', answer: 'kya', image_name: '', answer2: 'kya', etc_2: '', etc_3: '', etc_4: ''},
    { number: 11, question: '「きゅ」をローマ字で書きましょう。', answer: 'kyu', image_name: '', answer2: 'kyu', etc_2: '', etc_3: '', etc_4: ''},
    { number: 12, question: '「きょ」をローマ字で書きましょう。', answer: 'kyo', image_name: '', answer2: 'kyo', etc_2: '', etc_3: '', etc_4: ''}
];