const mondai = [
    { number: 1, question: '', answer: '', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '', answer: '', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '', answer: '', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];