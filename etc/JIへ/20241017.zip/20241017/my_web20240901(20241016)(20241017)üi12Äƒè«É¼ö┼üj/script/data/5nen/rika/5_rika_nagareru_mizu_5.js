const mondai = [
    { number: 1, question: 'P106。流れる水には、土を（　　　せ）たりするはたらきがある。', answer: 'つもらせ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P108。川が曲がったところの内側は、流れがゆるやかで、（　　　）のある石やすなが積もっている。', answer: 'まるみ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P109。海に近づくほど、川原の石の大きさが（　　　く）なっていく。', answer: 'ちいさく', image_name: '5_rika_nagareru_mizu_21.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P115。川の洪水（こうずい）によって、（　　　）が運ばれてくることがある。', answer: 'いわ', image_name: '5_rika_nagareru_mizu_22.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P118。（　　　）は、増水（ぞうすい）した川の水で洪水（こうずい）が起こらないように、一時的に水をたくわえる役わりも果たしている。（ダム）', answer: 'ダム', image_name: '5_rika_nagareru_mizu_29.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];