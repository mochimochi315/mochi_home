const mondai = [
    { number: 1, question: 'P106。水の流れが速いのは、ABのどちらですか。（半角英字）', answer: 'A', image_name: '5_rika_nagareru_mizu_01.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P106。Bの場所（曲がっているところの外側）のほうが、Aの場所（曲がっているところの内側）よりも、水の流れが（　　い）。', answer: 'はやい', image_name: '5_rika_nagareru_mizu_04.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P106。Bの場所（曲がっているところの外側）のほうが、Aの場所（曲がっているところの内側）よりも、地面（土）が（　　る）。', answer: 'けずられる', image_name: '5_rika_nagareru_mizu_05.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P108。川の内側は、川の深さが（　　い）。', answer: 'あさい', image_name: '5_rika_nagareru_mizu_13.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P108。川の外側は、水の流れが（　　い）。', answer: 'はやい', image_name: '5_rika_nagareru_mizu_10.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P111。かたむきが急な山の中では、川はばは、（　　い）。', answer: 'せまい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P111。平地や海の近くでは、小さくて（　　い）石やすなが多く見られる。', answer: 'まるい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P113～114。流れる水の量が多くなると、水の流れは（　　　）なる。', answer: 'はやく', image_name: '5_rika_nagareru_mizu_06.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P116。（　　　）は、洪水（こうずい）のときに、水の勢（いきお）いを弱めたり、流れてくる石などから田畑や家屋（かおく）を守ったりすることができる。', answer: 'すいがいぼうびりん', image_name: '5_rika_nagareru_mizu_17.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'P117。川の水が増えたとき、人が住む場所へ水があふれないように、一時的に水をたくわえる場所のことを（　　　）という。', answer: 'ゆうすいち', image_name: '5_rika_nagareru_mizu_15.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];