const mondai = [
    { number: 1, question: 'P106。流れる水には、（　　　）を運んだりするはたらきがある。', answer: 'つち', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P106。土が（　　　ている）ところでは、流れがゆるやかである。', answer: 'つもっている', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P109。海に近いところは、（　　　）地形になっている。', answer: 'たいらな', image_name: '5_rika_nagareru_mizu_20.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P111。山の中では、大きくて（　　　た）石が多くみられる。', answer: 'かくばった', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P115。砂（すな）やどろは、川から（　　　）に運ばれる。', answer: 'うみ', image_name: '5_rika_nagareru_mizu_23.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P117。川の水が増えたとき、人が住む場所へ水があふれないように、（　　　）をつくって川はばを広げている。', answer: 'かせんじき', image_name: '5_rika_nagareru_mizu_24.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P118。田畑は、水をたくわえる（　　　）の役わりを果たすことができる。（カタカナ）', answer: 'ダム', image_name: '5_rika_nagareru_mizu_25.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P120。これは、曲がっている川の川底の様子です。Bは、川の「外側」ですか、「内側」ですか。', answer: 'うちがわ', image_name: '5_rika_nagareru_mizu_26.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P121。スタジアム（野球場）の地下には、きょ大な（　　　）があります。', answer: 'すいそう', image_name: '5_rika_nagareru_mizu_27.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'P118。森が豊かな山は、一時的に水を（　　る）自然のダムになっている。', answer: 'たくわえる', image_name: '5_rika_nagareru_mizu_28.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];