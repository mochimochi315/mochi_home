const mondai = [
    { number: 1, question: 'P176。情報を記録・伝達する物や手段（しゅだん）のことを（　　　）と言う。', answer: 'メディア', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P179。放送時間の中でおさまるように、字幕（じまく）や図とともにまとめていく作業のことを（　　　）編集（へんしゅう）という。', answer: 'えいぞう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P180。選んだニュースの重大さや内容（ないよう）によって、放送する（　　　）や時間などを決めている。', answer: 'じゅんばん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P181。ニュースをわかりやすく（　　　）に伝えられるように、本番前に原稿に線を引いたりしている。', answer: 'せいかく', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P183。テレビ放送の情報から影響をうける例として、「（　　　）を見て、投票先を決める。」がある。', answer: 'せんきょじょうほう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P183。テレビ放送の情報から影響をうける例として、「（　　　）を見て、着る服や持ち物を決める。」がある。', answer: 'てんきよほう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P184。インターネットを使って、大勢の人と情報をやり取りすることができるSNS（LINE、フェイスブック、ティックトック）などのことを（　　　）メディアと呼んでいる。', answer: 'ソーシャル', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P185。次の事は、どのメディアのことを言っていますか、番号で答えましょう。「電池式のものは、停電（ていでん）しても使え、災害時（さいがいじ）の情報源（じょうほうげん）にもなる。」（1…テレビ、2…新聞、3…ラジオ、4…インターネット）（半角数字）', answer: '3', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P185。次の事は、どのメディアのことを言っていますか、番号で答えましょう。「文字や写真でくわしく説明した情報を、何度でも読み返せる。」（1…テレビ、2…新聞、3…ラジオ、4…インターネット）（半角数字）', answer: '2', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'P185。うその情報のことを（　　　）ニュースと呼ぶ。（カタカナ）', answer: 'フェイク', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];