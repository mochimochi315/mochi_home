const mondai = [
    { number: 1, question: 'P187。情報を受け取るわたしたちは、（　　　）情報だけで決めつけないようにしなくてはならない。', answer: 'ひとつの', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P179。本番中のスタジオと中継現場をつないでいる部屋を（　　　）室と呼ぶ。', answer: 'ふくちょうせい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P180。テレビ放送では、たくさんのスタッフが何重にも内容の（　　　）をしながら、番組制作をすすめている。（カタカナ）', answer: 'チェック', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P181。アナウンサーは、本番前に原稿に線を引いたり、くり返し読んで内容を（　　　）したりしています。', answer: 'かくにん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P181。ニュースの太陽に応じて、読む速さや（　　　）などを変えるようにしています。', answer: 'ひょうじょう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P187。放送局の人たちは、（　　　）な情報を伝えようとてしている。', answer: 'せいかく', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P187。（　　　の）取材先から情報を集めている。', answer: 'いくつもの', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];