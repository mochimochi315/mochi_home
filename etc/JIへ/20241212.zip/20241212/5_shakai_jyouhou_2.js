const mondai = [
    { number: 1, question: 'P176。一度にたくさんの人に情報を伝えるものを、（　　　）と言います。', answer: 'マスメディア', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P179。（　　　）では、編集責任者（へんしゅうせきにんしゃ）を中心に話し合い、番組で伝えるニュースの内容（ないよう）や順番を確かめている。', answer: 'うちあわせ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P180。選んだニュースの重大さや内容（ないよう）によって、放送する順番や（　　　）などを決めている。', answer: 'じかん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P181。ニュースを（　　　）正確に伝えられるように、本番前に原稿に線を引いたりしている。', answer: 'わかりやすく', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P183。放送局では、人によって意見が分かれている問題については、賛成（さんせい）と反対、期待と不安など、両方の意見を取り上げるようにして、（　　　）のない伝え方をするよう心がけています。', answer: 'かたより', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P183。テレビ放送の情報から影響をうける例として、「（　　　）を見て、自分の生活を見直す。」がある。（カタカナ）', answer: 'ニュース', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P184。ソーシャルメディアでは、あいまいな情報やまちがった情報が広まってしまい、（　　　）を与えてしまう例があった。', answer: 'ふあん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P185。次の事は、どのメディアのことを言っていますか、番号で答えましょう。「持ち歩いたり、記事を切りぬいて保存（ほぞん）したりできる。」（1…テレビ、2…新聞、3…ラジオ、4…インターネット）（半角数字）', answer: '2', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P185。次の事は、どのメディアのことを言っていますか、番号で答えましょう。「映像と音声でわかりやすく情報を伝える。」（1…テレビ、2…新聞、3…ラジオ、4…インターネット）（半角数字）', answer: '1', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'P185。情報が真実かどうか調べることを（　　　）チェックと呼ぶ。（カタカナ）', answer: 'ファクト', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];