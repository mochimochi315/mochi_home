const mondai = [
    { number: 1, question: 'P182。地震（じしん）や津波（つなみ）などが発生したときは、番組やニュースを中断して被害（ひがい）の様子を伝えたり、（　　　）をよびかけたりします。', answer: 'ひなん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P183。ニースとして放送するものを選ぶときには、「本当に（　　　）？」となやみながら選んでいます。', answer: 'これでよいのか', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P184。テレビ番組を同時に（　　　）でも見られるようにする取り組みが始まっている。（カタカナ）', answer: 'インターネット', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P184。インターネットにつながっているテレビ、インターネットを通してきけるラジオなど、インターネットと他のメディアが役割（やくわり）を（　　　）合ううことも増えています。', answer: 'おぎない', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P185。ソーシャルメディアを運営する会社でも、人をきずつける（　　　）や記事を取りのぞく努力を進めています。', answer: 'かきこみ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P187。情報をあつかうときに（　　　）をもつことは、わたしたちも同じだと思う。', answer: 'せきにん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];