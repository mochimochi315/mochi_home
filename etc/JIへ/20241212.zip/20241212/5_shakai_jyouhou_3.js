const mondai = [
    { number: 1, question: 'P177。テレビは、情報を（　　　）手段として多くの人が利用している。', answer: 'うけとる', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P179。事故（じこ）や事件（じけん）の現場（げんば）に記者やカメラマンがかけつけ、映像やインタビューをとり、くわしい情報を集めることを（　　　）と言う。', answer: 'しゅざい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P180。世の中は常に（つねに）動いているので、予定を変えて（　　　）ニュースを入れたりすることがある。', answer: 'あたらしい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P182。多くの人が（　　　）情報を伝えることも重要である。', answer: 'もとめている', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P183。テレビ放送の情報から影響をうける例として、「（　　　）を見て、行ったことのない場所に出かける。」がある。', answer: 'ごらくばんぐみ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P184。ソーシャルメディアでは、あいまいな情報や（　　　）情報が広まってしまうことがある。', answer: 'まちがった', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P185。次の事は、どのメディアのことを言っていますか、番号で答えましょう。「利用者からも、情報を発信できる。」（1…テレビ、2…新聞、3…ラジオ、4…インターネット）（半角数字）', answer: '4', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P185。次の事は、どのメディアのことを言っていますか、番号で答えましょう。「知りたい情報を自分で検索して知ることができる。」（1…テレビ、2…新聞、3…ラジオ、4…インターネット）（半角数字）', answer: '4', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P185。インターネットの利用によって、私たちの視聴者が、情報の（　　　）となる場合も増えています。', answer: 'はっしんしゃ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'P187。情報を受け取るわたしたちは、（　　　）できるメディアから、情報を得るようにしなくてはならない。', answer: 'しんよう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];