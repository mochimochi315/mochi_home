const mondai = [
    { number: 1, question: 'つぎの地図記ごうは、何をあらわしていますか？', answer: 'けいさつしょ', image_name: '3_shakai_chizu_kigou_04.png', answer2: 'けいさつしょ', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'つぎの地図記ごうは、何をあらわしていますか？', answer: 'しょうぼうしょ', image_name: '3_shakai_chizu_kigou_05.png', answer2: 'しょうぼうしょ', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'つぎの地図記ごうは、何をあらわしていますか？', answer: 'ゆうびんきょく', image_name: '3_shakai_chizu_kigou_06.png', answer2: 'ゆうびんきょく', etc_2: '', etc_3: '', etc_4: ''}
];