const mondai = [
    { number: 1, question: 'つぎの地図記ごうは、何をあらわしていますか？', answer: 'はし', image_name: '3_shakai_chizu_kigou_13.png', answer2: 'はし', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'つぎの地図記ごうは、何をあらわしていますか？', answer: 'た', image_name: '3_shakai_chizu_kigou_14.png', answer2: 'た', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'つぎの地図記ごうは、何をあらわしていますか？', answer: 'はたけ', image_name: '3_shakai_chizu_kigou_15.png', answer2: 'はたけ', etc_2: '', etc_3: '', etc_4: ''}
];