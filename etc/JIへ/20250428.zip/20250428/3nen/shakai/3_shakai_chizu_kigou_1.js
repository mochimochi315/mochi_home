const mondai = [
    { number: 1, question: 'つぎの地図記ごうは、何をあらわしていますか？', answer: 'えき', image_name: '3_shakai_chizu_kigou_01.png', answer2: 'えき', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'つぎの地図記ごうは、何をあらわしていますか？', answer: 'えき', image_name: '3_shakai_chizu_kigou_02.png', answer2: 'えき', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'つぎの地図記ごうは、何をあらわしていますか？', answer: 'しやくしょ', image_name: '3_shakai_chizu_kigou_03.png', answer2: 'しやくしょ', etc_2: '', etc_3: '', etc_4: ''}
];