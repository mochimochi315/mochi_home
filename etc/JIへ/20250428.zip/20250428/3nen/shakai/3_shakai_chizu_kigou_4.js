const mondai = [
    { number: 1, question: 'つぎの地図記ごうは、何をあらわしていますか？', answer: 'がっこう', image_name: '3_shakai_chizu_kigou_10.png', answer2: 'がっこう', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'つぎの地図記ごうは、何をあらわしていますか？', answer: 'びょういん', image_name: '3_shakai_chizu_kigou_11.png', answer2: 'びょういん', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'つぎの地図記ごうは、何をあらわしていますか？', answer: 'こうじょう', image_name: '3_shakai_chizu_kigou_12.png', answer2: 'こうじょう', etc_2: '', etc_3: '', etc_4: ''}
];