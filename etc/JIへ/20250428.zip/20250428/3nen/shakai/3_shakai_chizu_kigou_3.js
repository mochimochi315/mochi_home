const mondai = [
    { number: 1, question: 'つぎの地図記ごうは、何をあらわしていますか？', answer: 'てら', image_name: '3_shakai_chizu_kigou_07.png', answer2: 'てら', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'つぎの地図記ごうは、何をあらわしていますか？', answer: 'こうばん', image_name: '3_shakai_chizu_kigou_08.png', answer2: 'こうばん', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'つぎの地図記ごうは、何をあらわしていますか？', answer: 'じんじゃ', image_name: '3_shakai_chizu_kigou_09.png', answer2: 'じんじゃ', etc_2: '', etc_3: '', etc_4: ''}
];