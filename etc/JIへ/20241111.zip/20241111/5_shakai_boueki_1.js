const mondai = [
    { number: 1, question: 'P146。国と国との間で、品物を売り買いすること', answer: 'ぼうえき', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P149。2021年の日本の輸入品で、最も輸入額が多いものは？', answer: 'きかいるい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P155。食料生産の学習でも、輸入にたよりすぎるのは心配だと思ったけれど、（　　　）は輸入にたよるしかないのかな？', answer: 'てんねんしげん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P162のウを見て答えましょう。2020年の外国にある日本の会社の数は、1990年と比べると（　　　）いる。', answer: 'ふえて', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P158のイを見てこたえましょう。工業生産額が一番多いのは、（　　　）工業地帯である。', answer: 'ちゅうきょう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P159。海の近くに工場を建てれば、必要な原料や部品を船で（　　　）やすくなる。', answer: 'はこび', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P160。日本の国内にある工場のほとんどは（　　　）工場である。', answer: 'ちゅうしょう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P166。東大阪市の中小工場では、（　　　）ねじを生産している。', answer: 'さびない', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P168。高齢者の（　　　）なども、ロボットの協力が期待される。', answer: 'かいご', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'P171。教科書のA君は、「昔からの（　　　）を生かしている」を一番上にしている。', answer: 'でんとうぎじゅつ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];