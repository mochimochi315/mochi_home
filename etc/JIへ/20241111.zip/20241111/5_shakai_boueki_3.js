const mondai = [
    { number: 1, question: 'P148。1980年の日本の輸出品で、最も輸出額の多いものは？', answer: 'きかいるい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P149。1980年の日本の輸入品で、最も輸入額の多いものは？', answer: 'げんゆ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P151。日本は、（　　　）を99.7％輸入している。', answer: 'げんゆ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P154。日本の輸出入品は、主に（　　　）で輸送します。', answer: 'ふね', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P164。日本の自動車会社は、世界の各国に工場をつくり、現地で自動車を生産している。これを（　　　）という。', answer: 'かいがいせいさん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P164のイを見て答えましょう。日本の自動車会社は、（　　　）でも海外生産を行っている。（カタカナ）', answer: 'インド', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P158。工業のさかんな地域は、（　　　）に広がっている。', answer: 'うみぞい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P166。東大阪市には、5000以上の工場が集まっており、そのほとんどが（　　　）工場である。', answer: 'ちゅうしょう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P167。東大阪市の中小工場では、（　　　）やアイデアを生かし、人々のくらしを豊かにする製品の開発を続けている。', answer: 'たかいぎじゅつ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'P168。輸送用の機械やコンテナが炭素せんいを使うことで軽くなると、（　　　）をおさえることができる。', answer: 'ねんりょうのしょうひ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];