const mondai = [
    { number: 1, question: 'P148。2021年の日本の輸出品で、最も輸入額が多いものは？', answer: 'きかいるい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P151。主な燃料や原料の中で、日本が100％輸入しているものは？', answer: 'てっこうせき', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P151。日本は、主な燃料や原料の多くを（　　　）にたよっている。', answer: 'ゆにゅう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P151。工業製品の中で、一番輸出の割合が多いものは（　　　）ロボットである。', answer: 'さんぎょうよう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P152。日本は、（　　　）にめぐまれていない。', answer: 'てんねんしげん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P159のキーワードを読んで答えましょう。工業のさかんな地域は、（　　　）に広がっている。', answer: 'かくち', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P160。生産額の半分以上は、（　　　）工場がしめている。', answer: 'だい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P167。紙を加工する工場の上田さんの話では、（　　　　）製品をつくることが大切だと考えている。', answer: 'かんきょうにやさしい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P167のコを見て答えましょう。市内のすぐれた技術をもった工場が集まり、その技術やアイデア、質の高い製品を（　　　）している。', answer: 'しょうかい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'P173。植物の一部や動物のふんにょうなどを使って生み出すバイオマスエネルギーは、（　　　）エネルギーとして注目されている。', answer: 'かんきょうにやさしい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];