const mondai = [
    { number: 1, question: 'P192。POSシステムを通じて（　　　）するこれらの情報を生かして、店では商品の仕入れの量を決めています。', answer: 'かんり', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P193。全国各地にチェーン店がある会社では、（　　　）システムを通じて、それぞれの店の（　　　）の情報を本部に集めています。（英字、大文字）', answer: 'POS', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P193。わたしの店が加入しているチェーンでは、大量に集まった情報をもとに、さらによいと考えられる仕入れの量や値段（ねだん）の（　　　）を本部から提案（ていあん）してもらえます。', answer: 'せってい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P193。全国各地にチェーン店がある会社では、POSシステムを通じて、それぞれの店の（　　　）の情報を本部に集めています。', answer: 'うれゆき', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P193。コンビニエンスストアやファーストフード店にみられる、全国各地に展開（てんかい）する店のことを（　　　）店という。（カタカナ）', answer: 'チェーン', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P190。コンピューターやインターネットを使い、大量の情報を管理したり、はなれた場所ですぐにやりとりしたりすることができるしくみのことを（　　　）技術という。', answer: 'じょうほうつうしん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P190。買い物の支はらいでは、元気を使わない「（　　　）」が増えています。（カタカナ）', answer: 'キャッシュレス', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P191。現金でもキャッシュレスでも、（　　　）を通して会計するのは変わりません。（カタカナ）', answer: 'レジ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P192。集められ、整理された情報をもとに、できるだけ（　　　）も売り切れも出ない量を考えて、商品を発注しています。', answer: 'うれのこり', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];