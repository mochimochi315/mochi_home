const mondai = [
    { number: 1, question: 'P197。店内に設置（せっち）されたカメラの画像をAIが分析（ぶんせき）し、（　　　）商品を店員に知らせます。', answer: 'ふそくしている', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P197。インターネットを通じた買い物は、利用者の行動がすべて情報として残るため、その情報を生かしてさらに（　　　）に応じたサービスを提供（ていきょう）できるようになります。', answer: 'こじん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P199。情報をあつかう会社は、（　　　）を外部にもらさないように取り組むことが法律（ほうりつ）で定められています。', answer: 'こじんじょうほう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P199。クレジットカードの（　　　）はちゃんと守られているのかな。', answer: 'じょうほう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P201。情報通信技術の活用がさらに進むと、（　　　）どこでも買える商品がさらに増える。', answer: 'いつでも', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P201。これからは、さらに大量のデータが集まって、そこから引き出せる情報も増えると思うから、今では考えられないような（　　　）も受けられるようになると思います。（カタカナ）', answer: 'サービス', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];