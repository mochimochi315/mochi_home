const mondai = [
    { number: 1, question: 'ふりこが1往復する時間を調べます。アには、＋、−、×、÷のどの記号が入りますか。（ひらがな）', answer: 'わる', image_name: '5_rika_furiko_01.JPG', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'ふりこが10往復する平均の時間が12.0秒でした。このふりこが1往復する平均の時間は、何秒ですか。（小数）', answer: '1.2', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '実験するときに、2個のおもりをたてにつないではいけない理由は？ふりこの（　　　）が変わるから。', answer: 'ながさ', image_name: '5_rika_furiko_03.JPG', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'おもりの重さと1往復する時間の関係を調べる時、おもりの重さは、（　　　）条件にしなくてはならない。', answer: 'かえる', image_name: '5_rika_furiko_06.JPG', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'ふりこの長さと1往復する時間の関係を調べる時、ふれはばは、（　　　）条件にしなくてはならない。', answer: 'おなじ', image_name: '5_rika_furiko_08.JPG', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'ふりこの長さと1往復する時間の関係を調べる時、ふりこの長さは、（　　　）条件にしなくてはならない。', answer: 'かえる', image_name: '5_rika_furiko_10.JPG', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'ふりこのふれはばと1往復する時間の関係を調べる時、ふれはばは、（　　　）条件にしなくてはならない。', answer: 'かえる', image_name: '5_rika_furiko_11.JPG', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];