const mondai = [
    { number: 1, question: 'ふりこが1往復する時間を調べます。イには、＋、−、×、÷のどの記号が入りますか。（ひらがな）', answer: 'わる', image_name: '5_rika_furiko_02.JPG', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '実験するときのふりこの長さは、クリップの先から、おもりの（　　　）までの長さである。', answer: 'ちゅうしん', image_name: '5_rika_furiko_04.JPG', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'おもりの重さと1往復する時間の関係を調べる時、ふれはばは、（　　　）条件にしなくてはならない。', answer: 'おなじ', image_name: '5_rika_furiko_05.JPG', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'おもりの重さと1往復する時間の関係を調べる時、ふりこの長さは、（　　　）条件にしなくてはならない。', answer: 'おなじ', image_name: '5_rika_furiko_07.JPG', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'ふりこの長さと1往復する時間の関係を調べる時、おもりの重さは、（　　　）条件にしなくてはならない。', answer: 'おなじ', image_name: '5_rika_furiko_09.JPG', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'ふりこのふれはばと1往復する時間の関係を調べる時、おもりの重さは、（　　　）条件にしなくてはならない。', answer: 'おなじ', image_name: '5_rika_furiko_12.JPG', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'ふりこのふれはばと1往復する時間の関係を調べる時、ふりこの長さは、（　　　）条件にしなくてはならない。', answer: 'おなじ', image_name: '5_rika_furiko_13.JPG', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];