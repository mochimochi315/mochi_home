const mondai = [
    { number: 1, question: 'ふりこの場合、ふりこのふれはばを変えても、ふりこが1往復する時間は（　　　）。', answer: 'かわらない', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'ふりこの場合、ふりこの重さをかえても、ふりこが1往復する時間は（　　　）。', answer: 'かわらない', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'ふりこの場合、ふりこの長さを変えると、ふりこが1往復する時間は、（　　　ってしまう）。', answer: 'かわってしまう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'ふりこが1往復する時間は、ふりこの（　　　）で変わる。', answer: 'ながさ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'ふりこを長くすると、1往復する時間は、（　　く）なる。', answer: 'ながく', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'ふりこを短くすると、1往復する時間は、（　　く）なる。', answer: 'みじかく', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '1往復する時間を長くしたい時には、ふりこの長さを（　　く）すると良い。', answer: 'ながく', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: '1往復する時間を短くしたい時には、ふりこの長さを（　　く）すると良い。', answer: 'みじかく', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];