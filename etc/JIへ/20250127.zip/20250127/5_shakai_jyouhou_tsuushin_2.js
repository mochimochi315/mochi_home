const mondai = [
    { number: 1, question: 'P192。多くの店で使われている、売れ行きの情報を管理するための仕組みのことを（　　　）システムと呼んでいる。（英字、大文字）', answer: 'POS', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P192。店のレジでは、、商品についている（　　　）を機械で読み取り、「いつ、どの商品が、いくらで売れたか」といった情報をいっしゅんで記録しています。（カタカナ）', answer: 'バーコード', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P193。全国各地にチェーン店がある会社では、POSシステムを通じて、それぞれの店の売れ行きの情報を（　　　）に集めています。', answer: 'ほんぶ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P193。店から本部への発注にも情報通信技術を使うので、（　　　）の量などの情報も本部に集まります。', answer: 'しいれ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P193。この（　　　）のおかげで、商品が売れ残ってむだになることが減ったり、店の利益（りえき）が上がったりして、とても助かっている。', answer: 'ていあん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P193。全国各地にチェーン店がある会社では、POSシステムを通じて、それぞれの店の売れ行きの（　　　）を本部に集めています。', answer: 'じょうほう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P191。スマートフォンを持ち歩き、キャッシュレスの支はらいを希望する人が（　　　）きた。', answer: 'ふえて', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P191。（　　　）を通すことで、わたしたち消費者が買った情報が店に集まり、その情報を後で役立てることができます。（カタカナ）', answer: 'レジ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P192。集められ、整理された情報をもとに、できるだけ売れ残りも（　　　）も出ない量を考えて、商品を発注しています。', answer: 'うりきれ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];