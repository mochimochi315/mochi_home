const mondai = [
    { number: 1, question: 'P222のイを見て答えましょう。（　　　）が国土の3分の2をしめている。', answer: 'しんりん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '森林は、（　　　）に欠かせない資源（しげん）を生み出している。', answer: 'せいかつ', image_name: '', answer2: 'せいかつ', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P229　育てた苗木を山などに植えることを（　　　）といいます。', answer: 'しょくりん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P229　植林から伐採（ばっさい）までの期間を見ると、（　　　）年以上もかかる。（半角数字）', answer: '50', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '公害をくりかえさないために、公害の（　　　）を伝える取り組みがある。', answer: 'れきし', image_name: '', answer2: 'れきし', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '公害が広がってしまうと、元に戻るのに長い（　　　）がかかってしまう。', answer: 'ねんげつ', image_name: '', answer2: 'ねんげつ', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P239　市では、公害防止（　　　）をつくりました。', answer: 'じょうれい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: '環境（かんきょう）を守るためには、地域社会全体の（　　　）が必要である。', answer: 'どりょく', image_name: '', answer2: 'どりょく', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P241　ごみをできるだけ出さずに、資源（しげん）を有効（ゆうこう）に使う「（　　　）可能な社会」をめざしています。', answer: 'じぞく', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'P245　北九州市の公害対策（たいさく）は、（　　　）運動がきっかけで進みました。', answer: 'じゅうみん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];