const mondai = [
    { number: 1, question: 'P223　山を整えて森林をはぐくむことを（　　　）事業という。', answer: 'ちさん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P228　日本にある森林の半分近くは、木材などに使うことを目的として、人の手で植えられた（　　　）です。', answer: 'じんこうりん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P229　太陽の光がよくとどくように、一部の木を切りたおし、木と木の間を広げることを（　　　）という。', answer: 'かんばつ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '海岸にそって並んでいる林のことを海岸林（かいがんりん）と言います。海岸林は、（　　　）風や砂、騒音などをさえぎります。', answer: 'つよい', image_name: '', answer2: 'つよい', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P235　間伐（かんばつ）した木も使うことで、間伐（かんばつ）が進み、（　　　）の手入れも進む。', answer: 'しんりん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P238　産業の発展（はってん）によって環境（かんきょう）が悪化し、人々のくらしに被害（ひがい）が出ることを（　　　）という。', answer: 'こうがい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '地域（ちいき）の人々は、身のまわりの（　　　）を守るための取り組みに協力している。', answer: 'かんきょう', image_name: '', answer2: 'かんきょう', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P241　（　　　）には、使用ずみになった工業製品をリサイクルする工場が集まっています。（カタカナ）', answer: 'エコタウン', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P243　豊かな自然環境（かんきょう）は、人間のくらしに欠かすことのできない、さまざまな（　　　）を生み出している。', answer: 'しげん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'P226のイを見て答えましょう。高知県では、地元の（　　　）を使った校舎とつくえ、いすがある。', answer: 'もくざい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];