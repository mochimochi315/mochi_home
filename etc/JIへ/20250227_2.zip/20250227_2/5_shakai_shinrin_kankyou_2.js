const mondai = [
    { number: 1, question: 'P223　森林は、自然（　　　）を減らす。', answer: 'さいがい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P228　人間が植えた木は、最後まで人間が（　　　）をしてあげなくてはならない。', answer: 'せわ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P229　植えた木の成長をさまたげる雑草（ざっそう）や木をとりのぞくことを下草がり・（　　　）という。', answer: 'じょばつ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P230　わたしは、小型（こがた）の（　　　）を使い、植林から伐採（ばっさい）、搬出（はんしゅつ）まで、すべて一人で行っています。', answer: 'きかい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P232のアを見て答えましょう。森林づくりの活動をしている団体の数は、2003年と比べて2018年は（　　　）いる。', answer: 'ふえて', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P237　工場のえんとつから出るけむりにふくまれている、細かいちりやほこりのことを（　　　）という。', answer: 'ばいじん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '工場は（　　　）な廃水（はいすい）やけむりを出さないようにする設備（せつび）を整えた。', answer: 'ゆうがい', image_name: '', answer2: 'ゆうがい', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: '条例が（　　　）されると、公害を防ぐ設備（せつび）が整えられ、長年かけて青い海がよみがえってくる。', answer: 'せいび', image_name: '', answer2: 'せいび', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P242　環境イベントに参加すると、とても多くの市民が（　　　）問題に関わっていることがわかります。', answer: 'かんきょう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'P245　住民がうったえなければ、（　　　）は解決しない。', answer: 'こうがい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];