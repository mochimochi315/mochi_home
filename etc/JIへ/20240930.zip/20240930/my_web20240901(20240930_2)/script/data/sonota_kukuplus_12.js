const mondai = [
    { number: 1, question: '7×1＝', answer: '7', image_name: '', answer2: '7', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '7×2＝', answer: '14', image_name: '', answer2: '14', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '7×3＝', answer: '21', image_name: '', answer2: '21', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '7×4＝', answer: '28', image_name: '', answer2: '28', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '7×5＝', answer: '35', image_name: '', answer2: '35', etc_2: '', etc_3: '', etc_4: ''}
];