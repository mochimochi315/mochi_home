const mondai = [
    { number: 1, question: '835÷4をひっ算で計算しましょう。（答えが、5あまり2の時には、5***2と入力します。）', answer: '208***3', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '623÷3をひっ算で計算しましょう。（答えが、5あまり2の時には、5***2と入力します。）', answer: '207***2', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];