const mondai = [
    { number: 1, question: '817-458', answer: '359', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '613-165', answer: '448', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];