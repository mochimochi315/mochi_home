const mondai = [
    { number: 1, question: '531÷6をひっ算で計算しましょう。（答えが、5あまり2の時には、5***2と入力します。）', answer: '88***3', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '170÷9をひっ算で計算しましょう。（答えが、5あまり2の時には、5***2と入力します。）', answer: '18***8', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '543÷8をひっ算で計算しましょう。（答えが、5あまり2の時には、5***2と入力します。）', answer: '67***7', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];