const mondai = [
    { number: 1, question: '26×34', answer: '884', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '14×58', answer: '812', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];