const mondai = [
    { number: 1, question: '23×64', answer: '1472', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '43×48', answer: '2064', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];