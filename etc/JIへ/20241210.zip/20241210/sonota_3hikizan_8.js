const mondai = [
    { number: 1, question: '130-76', answer: '54', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];