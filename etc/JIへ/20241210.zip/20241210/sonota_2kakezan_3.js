const mondai = [
    { number: 1, question: '85×83', answer: '7055', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '37×84', answer: '3108', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];