const mondai = [
    { number: 1, question: '203÷7をひっ算で計算しましょう。（割り切れる問題です。）', answer: '29', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '552÷8をひっ算で計算しましょう。（割り切れる問題です。）', answer: '69', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '546÷7をひっ算で計算しましょう。（割り切れる問題です。）', answer: '78', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];