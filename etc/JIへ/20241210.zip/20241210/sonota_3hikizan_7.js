const mondai = [
    { number: 1, question: '324-267', answer: '57', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '575-479', answer: '96', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];