const mondai = [
    { number: 1, question: '962÷3をひっ算で計算しましょう。（答えが、5あまり2の時には、5***2と入力します。）', answer: '320***2', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '961÷4をひっ算で計算しましょう。（答えが、5あまり2の時には、5***2と入力します。）', answer: '240***1', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];