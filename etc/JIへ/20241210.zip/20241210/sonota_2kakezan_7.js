const mondai = [
    { number: 1, question: '78×37', answer: '2886', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '64×98', answer: '6272', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];