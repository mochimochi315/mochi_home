const mondai = [
    { number: 1, question: '576+329', answer: '905', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '133+268', answer: '401', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];