const mondai = [
    { number: 1, question: '123÷7をひっ算で計算しましょう。（答えが、5あまり2の時には、5***2と入力します。）', answer: '17***4', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '610÷8をひっ算で計算しましょう。（答えが、5あまり2の時には、5***2と入力します。）', answer: '76***2', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '232÷6をひっ算で計算しましょう。（答えが、5あまり2の時には、5***2と入力します。）', answer: '38***4', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];