const mondai = [
    { number: 1, question: '204÷6をひっ算で計算しましょう。（割り切れる問題です。）', answer: '34', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '333÷9をひっ算で計算しましょう。（割り切れる問題です。）', answer: '37', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '315÷7をひっ算で計算しましょう。（割り切れる問題です。）', answer: '45', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];