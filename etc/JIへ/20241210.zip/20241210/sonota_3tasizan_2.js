const mondai = [
    { number: 1, question: '268+179', answer: '447', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '497+265', answer: '762', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];