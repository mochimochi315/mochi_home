const mondai = [
    { number: 1, question: '710-523', answer: '187', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '832-534', answer: '298', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];