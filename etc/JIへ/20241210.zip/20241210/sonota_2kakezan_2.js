const mondai = [
    { number: 1, question: '96×89', answer: '8544', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '67×72', answer: '4824', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];