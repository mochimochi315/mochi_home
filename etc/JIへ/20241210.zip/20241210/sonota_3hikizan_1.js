const mondai = [
    { number: 1, question: '447-179', answer: '268', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '943-298', answer: '645', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];