const mondai = [
    { number: 1, question: '437+263', answer: '700', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '296+504', answer: '800', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];