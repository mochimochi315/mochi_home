const mondai = [
    { number: 1, question: '56×75', answer: '4200', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '99×92', answer: '9108', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];