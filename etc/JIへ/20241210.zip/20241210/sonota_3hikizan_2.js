const mondai = [
    { number: 1, question: '725-457', answer: '268', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '750-269', answer: '481', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];