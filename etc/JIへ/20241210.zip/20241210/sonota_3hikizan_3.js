const mondai = [
    { number: 1, question: '820-544', answer: '276', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '640-261', answer: '379', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];