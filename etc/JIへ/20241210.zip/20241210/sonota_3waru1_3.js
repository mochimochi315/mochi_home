const mondai = [
    { number: 1, question: '136÷8をひっ算で計算しましょう。（割り切れる問題です。）', answer: '17', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '402÷6をひっ算で計算しましょう。（割り切れる問題です。）', answer: '67', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '504÷8をひっ算で計算しましょう。（割り切れる問題です。）', answer: '63', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];