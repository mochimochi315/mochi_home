const mondai = [
    { number: 1, question: '841÷2をひっ算で計算しましょう。（答えが、5あまり2の時には、5***2と入力します。）', answer: '420***1', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '965÷6をひっ算で計算しましょう。（答えが、5あまり2の時には、5***2と入力します。）', answer: '160***5', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];