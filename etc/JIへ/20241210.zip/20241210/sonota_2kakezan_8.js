const mondai = [
    { number: 1, question: '89×39', answer: '3471', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];