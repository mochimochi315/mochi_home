const mondai = [
    { number: 1, question: '10÷5＝', answer: '2', image_name: '', answer2: '2', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '16÷4＝', answer: '4', image_name: '', answer2: '4', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '18÷3＝', answer: '6', image_name: '', answer2: '6', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '16÷2＝', answer: '8', image_name: '', answer2: '8', etc_2: '', etc_3: '', etc_4: ''}
];