const mondai = [
    { number: 1, question: '3÷3＝', answer: '1', image_name: '', answer2: '1', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '6÷2＝', answer: '3', image_name: '', answer2: '3', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '5÷1＝', answer: '5', image_name: '', answer2: '5', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '54÷9＝', answer: '6', image_name: '', answer2: '6', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '64÷8＝', answer: '8', image_name: '', answer2: '8', etc_2: '', etc_3: '', etc_4: ''}
];