const mondai = [
    { number: 1, question: '9÷9＝', answer: '1', image_name: '', answer2: '1', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '24÷8＝', answer: '3', image_name: '', answer2: '3', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '35÷7＝', answer: '5', image_name: '', answer2: '5', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '42÷6＝', answer: '7', image_name: '', answer2: '7', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '45÷5＝', answer: '9', image_name: '', answer2: '9', etc_2: '', etc_3: '', etc_4: ''}
];