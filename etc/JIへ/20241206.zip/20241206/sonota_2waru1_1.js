const mondai = [
    { number: 1, question: '1÷1＝', answer: '1', image_name: '', answer2: '1', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '18÷9＝', answer: '2', image_name: '', answer2: '2', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '32÷8＝', answer: '4', image_name: '', answer2: '4', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '42÷7＝', answer: '6', image_name: '', answer2: '6', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '48÷6＝', answer: '8', image_name: '', answer2: '8', etc_2: '', etc_3: '', etc_4: ''}
];