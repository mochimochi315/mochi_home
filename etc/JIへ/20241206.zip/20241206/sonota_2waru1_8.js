const mondai = [
    { number: 1, question: '8÷8＝', answer: '1', image_name: '', answer2: '1', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '21÷7＝', answer: '3', image_name: '', answer2: '3', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '30÷6＝', answer: '5', image_name: '', answer2: '5', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '35÷5＝', answer: '7', image_name: '', answer2: '7', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '36÷4＝', answer: '9', image_name: '', answer2: '9', etc_2: '', etc_3: '', etc_4: ''}
];