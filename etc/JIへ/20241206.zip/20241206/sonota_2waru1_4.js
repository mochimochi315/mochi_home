const mondai = [
    { number: 1, question: '4÷4＝', answer: '1', image_name: '', answer2: '1', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '9÷3＝', answer: '3', image_name: '', answer2: '3', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '10÷2＝', answer: '5', image_name: '', answer2: '5', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '7÷1＝', answer: '7', image_name: '', answer2: '7', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '72÷9＝', answer: '8', image_name: '', answer2: '8', etc_2: '', etc_3: '', etc_4: ''}
];