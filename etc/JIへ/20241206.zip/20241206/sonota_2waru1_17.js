const mondai = [
    { number: 1, question: '16÷8＝', answer: '2', image_name: '', answer2: '2', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '28÷7＝', answer: '4', image_name: '', answer2: '4', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '36÷6＝', answer: '6', image_name: '', answer2: '6', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '40÷5＝', answer: '8', image_name: '', answer2: '8', etc_2: '', etc_3: '', etc_4: ''}
];