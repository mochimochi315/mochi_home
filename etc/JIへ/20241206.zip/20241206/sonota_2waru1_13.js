const mondai = [
    { number: 1, question: '8÷4＝', answer: '2', image_name: '', answer2: '2', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '12÷3＝', answer: '4', image_name: '', answer2: '4', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '12÷2＝', answer: '6', image_name: '', answer2: '6', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '8÷1＝', answer: '8', image_name: '', answer2: '8', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '81÷9＝', answer: '9', image_name: '', answer2: '9', etc_2: '', etc_3: '', etc_4: ''}
];