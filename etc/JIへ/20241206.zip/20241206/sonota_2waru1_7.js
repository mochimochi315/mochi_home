const mondai = [
    { number: 1, question: '7÷7＝', answer: '1', image_name: '', answer2: '1', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '18÷6＝', answer: '3', image_name: '', answer2: '3', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '25÷5＝', answer: '5', image_name: '', answer2: '5', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '28÷4＝', answer: '7', image_name: '', answer2: '7', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '27÷3＝', answer: '9', image_name: '', answer2: '9', etc_2: '', etc_3: '', etc_4: ''}
];