const mondai = [
    { number: 1, question: 'P166　かん電池をつないで電流を流すと、電磁石は（ぼう　　　）のように、鉄のゼムクリップを引きつけました。', answer: 'ぼうじしゃく', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '①（赤色のはり）は、N極、S極のどちらになりますか。', answer: 'えぬきょく', image_name: '5_rika_denryuu_05.png', answer2: 'えぬきょく', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P168　電磁石に電流を流した時、①は、N極、S極のどちらになりますか。', answer: 'えぬきょく', image_name: '5_rika_denryuu_07.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P168　電磁石には、ぼう磁石のようにN極と（　　　）がある。', answer: 'えすきょく', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P167　かんい検流計は、流れる電流の向きや（　　　）を調べることができる。', answer: 'おおきさ', image_name: '5_rika_denryuu_09.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '何A（アンペア）ですか。（半角数字）', answer: '0.3', image_name: '5_rika_denryuu_10.png', answer2: '0.3', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P170　電流の大きさを変えて、電磁石の強さを調べる実験では、同じ条件は、（　　　）です。（カタカナとひらがな）', answer: 'コイルのまきすう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P174　（　　　）を大きくすると、電磁石は強くなる。', answer: 'でんりゅう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: '右と左をくらべると、強い電磁石は、どちらですか。', answer: 'みぎ', image_name: '5_rika_denryuu_13.png', answer2: 'みぎ', etc_2: '', etc_3: '', etc_4: ''}
];