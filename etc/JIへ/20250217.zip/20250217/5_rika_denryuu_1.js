const mondai = [
    { number: 1, question: 'P163　①の部分を何といいますか。（カタカナ）', answer: 'コイル', image_name: '5_rika_denryuu_01.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P168　電磁石に電流を流した時、①は、N極、S極のどちらになりますか。', answer: 'えすきょく', image_name: '5_rika_denryuu_03.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '②（銀色のはり）は、N極、S極のどちらになりますか。', answer: 'えすきょく', image_name: '5_rika_denryuu_06.png', answer2: 'えすきょく', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P168　電磁石に電流を流した時、②は、N極、S極のどちらになりますか。', answer: 'えすきょく', image_name: '5_rika_denryuu_08.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P168　コイルに流れる電流の向きが逆になると、電磁石の（　　　）とS極が入れかわる。', answer: 'えぬきょく', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P167　かんい検流計を（　　　）なところに置く。', answer: 'すいへい', image_name: '5_rika_denryuu_09.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '何A（アンペア）ですか。（半角数字）', answer: '1.5', image_name: '5_rika_denryuu_11.png', answer2: '1.5', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P171　コイルのまき数を変えて、電磁石の強さを調べる実験では、変える条件は、（　　　）です。（カタカナとひらがな）', answer: 'コイルのまきすう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P174　（　　　）を多くすると、電磁石は強くなる。（カタカナとひらがな）', answer: 'コイルのまきすう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: '右と左をくらべると、強い電磁石は、どちらですか。', answer: 'みぎ', image_name: '5_rika_denryuu_14.png', answer2: 'みぎ', etc_2: '', etc_3: '', etc_4: ''}
];