const mondai = [
    { number: 1, question: 'P163　②の部分を何といいますか。', answer: 'てつしん', image_name: '5_rika_denryuu_02.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P168　電磁石に電流を流した時、②は、N極、S極のどちらになりますか。', answer: 'えぬきょく', image_name: '5_rika_denryuu_04.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P167　かん電池の向きを変えると、（　　　）の向きも変わる。', answer: 'でんりゅう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P168　電磁石は、コイルに電流が流れているときだけ、（　　　）の性質をもつ。', answer: 'じしゃく', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P167　かんい検流計は、流れる電流の（　　　）や大きさを調べることができる。', answer: 'むき', image_name: '5_rika_denryuu_09.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P167　かんい検流計の切りかえスイッチを「（　　　）（5A）」側にする。', answer: 'でんじしゃく', image_name: '5_rika_denryuu_09.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P170　電流の大きさを変えて、電磁石の強さを調べる実験では、変える条件は、（　　　）です。', answer: 'でんりゅうのおおきさ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P171　コイルのまき数を変えて、電磁石の強さを調べる実験では、同じ条件は、（　　　）です。', answer: 'でんりゅうのおおきさ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: '100回巻きの電磁石を上の図のように、50回巻きにすると、電磁石は、強くなりますか、弱くなりますか。', answer: 'よわくなる', image_name: '5_rika_denryuu_12.png', answer2: 'よわくなる', etc_2: '', etc_3: '', etc_4: ''}
];