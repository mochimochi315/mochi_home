const mondai = [
    { number: 1, question: '3+8＝', answer: '11', image_name: '', answer2: '11', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '7+3＝', answer: '10', image_name: '', answer2: '10', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '9+3＝', answer: '12', image_name: '', answer2: '12', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '6+5＝', answer: '11', image_name: '', answer2: '11', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '4+8＝', answer: '12', image_name: '', answer2: '12', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '10-5＝', answer: '5', image_name: '', answer2: '5', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '12-7＝', answer: '5', image_name: '', answer2: '5', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: '15-9＝', answer: '6', image_name: '', answer2: '6', etc_2: '', etc_3: '', etc_4: ''}
];