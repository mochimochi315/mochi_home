const mondai = [
    { number: 1, question: '6+5＝', answer: '11', image_name: '', answer2: '11', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '8+7＝', answer: '15', image_name: '', answer2: '15', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '9+3＝', answer: '12', image_name: '', answer2: '12', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '6+7＝', answer: '13', image_name: '', answer2: '13', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '8+9＝', answer: '17', image_name: '', answer2: '17', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '11-9＝', answer: '2', image_name: '', answer2: '2', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '14-8＝', answer: '6', image_name: '', answer2: '6', etc_2: '', etc_3: '', etc_4: ''}
];