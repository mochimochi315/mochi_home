const mondai = [
    { number: 1, question: '5+7＝', answer: '12', image_name: '', answer2: '12', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '8+3＝', answer: '11', image_name: '', answer2: '11', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '8+2＝', answer: '10', image_name: '', answer2: '10', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '9+6＝', answer: '15', image_name: '', answer2: '15', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '4+9＝', answer: '13', image_name: '', answer2: '13', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '11-5＝', answer: '6', image_name: '', answer2: '6', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '13-9＝', answer: '4', image_name: '', answer2: '4', etc_2: '', etc_3: '', etc_4: ''}
];