const mondai = [
    { number: 1, question: '4+7＝', answer: '11', image_name: '', answer2: '11', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '7+6＝', answer: '13', image_name: '', answer2: '13', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '9+6＝', answer: '15', image_name: '', answer2: '15', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '9+5＝', answer: '14', image_name: '', answer2: '14', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '7+8＝', answer: '15', image_name: '', answer2: '15', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '10-8＝', answer: '2', image_name: '', answer2: '2', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '13-4＝', answer: '9', image_name: '', answer2: '9', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: '16-9＝', answer: '7', image_name: '', answer2: '7', etc_2: '', etc_3: '', etc_4: ''}
];