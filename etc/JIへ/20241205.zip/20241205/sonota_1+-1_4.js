const mondai = [
    { number: 1, question: '3+7＝', answer: '10', image_name: '', answer2: '10', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '6+9＝', answer: '15', image_name: '', answer2: '15', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '9+2＝', answer: '11', image_name: '', answer2: '11', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '9+4＝', answer: '13', image_name: '', answer2: '13', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '3+8＝', answer: '11', image_name: '', answer2: '11', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '10-4＝', answer: '6', image_name: '', answer2: '6', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '12-6＝', answer: '6', image_name: '', answer2: '6', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: '15-8＝', answer: '7', image_name: '', answer2: '7', etc_2: '', etc_3: '', etc_4: ''}
];