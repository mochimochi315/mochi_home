const mondai = [
    { number: 1, question: '5+5＝', answer: '10', image_name: '', answer2: '10', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '7+9＝', answer: '16', image_name: '', answer2: '16', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '9+9＝', answer: '18', image_name: '', answer2: '18', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '7+6＝', answer: '13', image_name: '', answer2: '13', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '2+9＝', answer: '11', image_name: '', answer2: '11', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '11-3＝', answer: '8', image_name: '', answer2: '8', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '13-7＝', answer: '6', image_name: '', answer2: '6', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: '18-9＝', answer: '9', image_name: '', answer2: '9', etc_2: '', etc_3: '', etc_4: ''}
];