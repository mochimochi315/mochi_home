const mondai = [
    { number: 1, question: '4+8＝', answer: '12', image_name: '', answer2: '12', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '7+7＝', answer: '14', image_name: '', answer2: '14', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '9+7＝', answer: '16', image_name: '', answer2: '16', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '4+6＝', answer: '10', image_name: '', answer2: '10', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '9+8＝', answer: '17', image_name: '', answer2: '17', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '10-9＝', answer: '1', image_name: '', answer2: '1', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '13-5＝', answer: '8', image_name: '', answer2: '8', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: '17-8＝', answer: '9', image_name: '', answer2: '9', etc_2: '', etc_3: '', etc_4: ''}
];