const mondai = [
    { number: 1, question: '1+9＝', answer: '10', image_name: '', answer2: '10', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '6+6＝', answer: '12', image_name: '', answer2: '12', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '8+8＝', answer: '16', image_name: '', answer2: '16', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '6+4＝', answer: '10', image_name: '', answer2: '10', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '8+7＝', answer: '15', image_name: '', answer2: '15', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '10-1＝', answer: '9', image_name: '', answer2: '9', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '12-3＝', answer: '9', image_name: '', answer2: '9', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: '14-9＝', answer: '5', image_name: '', answer2: '5', etc_2: '', etc_3: '', etc_4: ''}
];