const mondai = [
    { number: 1, question: '5+6＝', answer: '11', image_name: '', answer2: '11', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '8+2＝', answer: '10', image_name: '', answer2: '10', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '9+1＝', answer: '10', image_name: '', answer2: '10', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '8+6＝', answer: '14', image_name: '', answer2: '14', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '3+9＝', answer: '12', image_name: '', answer2: '12', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '11-4＝', answer: '7', image_name: '', answer2: '7', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '13-8＝', answer: '5', image_name: '', answer2: '5', etc_2: '', etc_3: '', etc_4: ''}
];