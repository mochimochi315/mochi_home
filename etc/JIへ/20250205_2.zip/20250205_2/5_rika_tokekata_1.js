const mondai = [
    { number: 1, question: 'P139　メスシリンダーは、（　　　）なところに置く。', answer: 'すいへい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P143　①と③の重さは、同じですか、ちがいますか。（　　　）', answer: 'おなじ', image_name: '5_rika_tokekata_01.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P146　ものによって、決まった量の水にとける量は（　　　）。', answer: 'ちがう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P148　食塩水の水の量を２倍に増やすと、食塩のとける量は、（　　　）に増える。（すべてひらがな）', answer: 'にばい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P149　水の温度ととけるものの量の関係を調べる実験では、変えない条件は、（　　　）である。', answer: 'みずのりょう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P150　食塩は、水の温度を上げても、とける量がほとんど（　　　）しない。', answer: 'へんか', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P151　ミョウバンの水よう液を冷やすと、とけていた（　　　）が現れる。（カタカナ）', answer: 'ミョウバン', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P153　さらに（　　　）に折る。', answer: 'はんぶん', image_name: '5_rika_tokekata_02.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P154　ミョウバンの水よう液を冷やした場合には、ミョウバンのつぶを取り出すことが（　　　）。', answer: 'できる', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'P156　ミョウバンの水よう液で、水をじょうはつさせると、とけていたミョウバンを取り出すことか（　　　）。', answer: 'できる', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];