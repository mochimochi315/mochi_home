const mondai = [
    { number: 1, question: 'P139　メスシリンダーに液を入れる時には、やや（　　　）に入れる。', answer: 'すくなめ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P146　決まった量の水にとけるものの量には、（　　　る）。', answer: 'かぎりがある', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P148　ミョウバンの水よう液の水の量を２倍に増やすと、ミョウバンのとける量は、（　　　）に増える。（すべてひらがな）', answer: 'にばい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P149　水の温度ととけるものの量の関係を調べる実験では、変える条件は、（　　　）である。', answer: 'みずのおんど', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P150　10度や30度の時には、食塩のほうが水に多くとけるが、60度の時には、（　　　）のほうが水に多くとける。（カタカナ）', answer: 'ミョウバン', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P150　水の温度を変化させたとき、とける量の変化のしかたは、（　　　）によってちがう。', answer: 'とかすもの', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P153　液の中にとけ切れなかったつぶがあるときは、ろ紙でこして、つぶと水よう液を（　　　）ことができます。', answer: 'わける', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P153　液は（　　　）ぼうに伝わらせて注ぐ。（カタカナ）', answer: 'ガラス', image_name: '5_rika_tokekata_04.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P154　食塩水の水よう液を冷やした場合には、食塩水のつぶを取り出すことが（　　　）。', answer: 'できない', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'ミョウバンの水よう液を冷やすと、白いものが出てくるが、水の温度を（　　　）と、白いものをもう一度とかすことができる。', answer: 'あげる', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];