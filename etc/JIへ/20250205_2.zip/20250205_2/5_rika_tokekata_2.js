const mondai = [
    { number: 1, question: 'P139　液面のへこんだ（　　　）の面を、真横から見て読む。', answer: 'した', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P144　水にとけたものは、目には見えなくなっても、（　　　）の中にある。', answer: 'とけたえき', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P148　水の量を2倍に増やすと、水にとけるものの量も（　　　）に増える。（すべてひらがな）', answer: 'にばい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P148　水の量を増やすと、水にとけるものの量も（　　　る）。', answer: 'ふえる', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P156　食塩水で、水をじょう発させると、とけていた食塩を取り出すことか（　　　）。', answer: 'できる', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P150　（　　　）は、水の温度を上げると、とける量が増える。（カタカナ）', answer: 'ミョウバン', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P151　食塩水を冷やしても、とけていた（　　　）は、ほとんど現れない。', answer: 'しょくえん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P153　ろ紙をろうとにつけるときには、ろ紙を（）でぬらして、ぴったりとつける。', answer: 'みず', image_name: '5_rika_tokekata_03.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P154　水よう液を冷やすと、ミョウバンの水よう液の場合には、ミョウバンを取り出すことができるが、食塩水の場合には、食塩をほとんど（　　　）ことができない。', answer: 'とりだす', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'P156　水よう液をじょう発させると、ミョウバンの水よう液の場合も、食塩水の場合も、とけていたものを取り出すことが（　　　）。', answer: 'できる', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];