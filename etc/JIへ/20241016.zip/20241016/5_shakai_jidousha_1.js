const mondai = [
    { number: 1, question: 'P124のクを見て答えましょう。2021年の自動車の生産台数は、1935年と比べると、（　　　）（ふえている、へっている）', answer: 'ふえている', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P127。かんだ町にある自動車工場の広さは、国立競技場約（　　　）個分。（半角数字）', answer: '21', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P128。とそう工場では、1日に25mプール（　　　）ぱい分の水を使う。（半角数字）', answer: '20', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P128。自動車工場では、（　　　）にそって多くの人やロボットが作業をしています。（カタカナ）', answer: 'ライン', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P128。とそう工場では、色の（　　　）を３回くり返し、きれいにぬり上げます。', answer: 'ぬりつけ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P130。部品をラインまで運ぶのは（　　　）の機械です。', answer: 'じどう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P131。同じ作業を繰り返してなれすぎてしまうと、ミスやけがつながることがあるので、2時間おきに（　　　）を入れたりしている。', answer: 'きゅうけい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P133のカと教科書の本文を読んで答えましょう。関連工場を支える（　　　）工場もたくさんあります。', answer: 'かんれん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P138。回転するシートがついた車は、足に（　　　）のある人でも運転することができる。', answer: 'しょうがい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'P140。だれでも（　　　）やすい車づくりをめざしている。', answer: 'つかい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];