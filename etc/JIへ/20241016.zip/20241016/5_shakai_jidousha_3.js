const mondai = [
    { number: 1, question: 'P126。福岡県の（　　　）町にある工場では、大量の自動車を生産しています。', answer: 'かんだ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P128。ロボットによる溶接（ようせつ）だと、30秒ほどの間に、（　　　）か所も溶接ができます。（半角数字）', answer: '40', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P128。車体工場では、（　　　）の部品を熱でとかしてつなぎ合わせ、形を仕上げていきます。', answer: 'しゃたい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P129。組み立て工場では、エンジンや（　　　）などを取り付けています。（カタカナ）', answer: 'フロントガラス', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P130。組み立て工場では、（　　　）を知らせるボタンとランプがあり、すぐに対策をとることができるようになっている。', answer: 'いじょう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P130。大きな部品の取り付けは、（　　　）に支えてもらいます。（カタカナ）', answer: 'ロボット', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P131。人の力では大変な作業を、（　　　）にまかせている。（カタカナ）', answer: 'ロボット', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P132。シートは、（　　　）につくり、決められた時間までに運んでいる。', answer: 'けいかくてき', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P137。（　　　）を助ける機能は、安全運転を支えている。', answer: 'ちゅうしゃ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'P138。電気自動車は、（　　　）のよごれや地球温暖化（おんだんか）の原因にもなる排出（はいしゅつ）ガスの量をおさえることができる。', answer: 'くうき', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];