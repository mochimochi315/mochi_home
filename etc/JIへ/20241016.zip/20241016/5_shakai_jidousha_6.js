const mondai = [
    { number: 1, question: 'P131。細かい部品の取り付けや最後の（　　　）は、人がしっかり行っていたね。', answer: 'けんさ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P132。シート工場では、人とロボットが作業を（　　　）しながら、ライン上で次々に製品を組み立てている。', answer: 'ぶんたん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P133。自動車の組み立てに必要な部品を、必要な（　　　）までに、必要な数と種類だけ、組み立て工場にとどける仕組みのことをジャスト・イン・タイム方式という。', answer: 'じこく', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P134。工場から（　　　）地域へ自動車を運ぶときは、キャリアカーだけを使います。', answer: 'ちかい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P138。しょうがいの有無（うむ）、年令や性別、言葉のちがいなどにかかわらず、だれもが等しく使いやすいように、あらかじめ安全で便利なものをつくろうとする考え方のことを（　　　）という。（カタカナ）', answer: 'ユニバーサルデザイン', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P135。車を運ぶ専用船の高さは、（　　　）m（半角数字）', answer: '47', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P134。自動車を船に積み込むときは、となりの車との間を、（　　　）一つ分まで近づけてならべます。', answer: 'にぎりこぶし', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P139。自動車工場では、（　　　）にやさしい工場をめざしている。', answer: 'かんきょう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P139。自動車工場では、（　　　）の作業員もたくさん働いています。', answer: 'じょせい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'P139。自動車工場では、（　　　）にしょうがいのある人も、他の人と同じように働いています。', answer: 'ちょうかく', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];