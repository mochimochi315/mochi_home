const mondai = [
    { number: 1, question: 'P125のケを見て答えましょう。世界の自動車生産台数が一番多い国は（　　　）です。', answer: 'ちゅうごく', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P128。まちがいが起こらないように、（　　　）を使って管理しています。（カタカナ）', answer: 'コンピューター', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P128～P129。①プレス工場②（　　　）③とそう工場④組み立て工場で、作業を分担して仕事を進めている。', answer: 'しゃたいこうじょう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P129。決められた順番どおりに人やロボットが分担して作業を行い、製品をつくり上げていく一つの流れのことを（　　　）といいます。（カタカナ）', answer: 'ライン', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P129。組み立て工場では、1～2分に1台の割合で（　　　）ができあがっていく。', answer: 'じどうしゃ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P130。どの部品を取ればよいか、（　　　）がついて教えてくれるしくみになっているので、まちがうことはほとんどありません。（カタカナ）', answer: 'ランプ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P132。数日前にとどいた（　　　）に合わせて、シートを計画的に作っている。', answer: 'ちゅうもん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P132。自動車に使われる大量の部品は、（　　　）工場で生産されている。', answer: 'かんれん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P137。（　　　）ブレーキの機能は、自動車を運転するたくさんの人の安全を守ることにつながっている。', answer: 'きんきゅう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'P138。ハイブリット車は、ガソリンと（　　　）を組み合わせて使う車で、環境にやさしい自動車だといえる。', answer: 'でんき', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];