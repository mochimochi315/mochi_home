const mondai = [
    { number: 1, question: 'P92。約18週のヒトの子どもの身長は、約（　　　）㎝です。（半角数字で）', answer: '25', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P92。約18週のヒトの子どもの体重は、約（　　　）gです。（半角数字で）', answer: '250', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P92。約4週のヒトの子どもの身長は、約（　　　）㎝です。（半角数字で）', answer: '0.4', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P92。約4週のヒトの子どもの体重は、約（　　　）gです。（半角数字で）', answer: '0.02', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P92。これは、約（　　　）週頃の胎児（たいじ）の画像です。（半角数字で）', answer: '4', image_name: '5-rika-hito_no_tanjyou-10.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P92。これは、約（　　　）週頃の胎児（たいじ）の画像です。（半角数字で）', answer: '7', image_name: '5-rika-hito_no_tanjyou-11.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P92。これは、約（　　　）週頃の胎児（たいじ）の画像です。（半角数字で）', answer: '20', image_name: '5-rika-hito_no_tanjyou-12.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];