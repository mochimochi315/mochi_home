const mondai = [
    { number: 1, question: '9×6＝', answer: '54', image_name: '', answer2: '54', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '9×7＝', answer: '63', image_name: '', answer2: '63', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '9×8＝', answer: '72', image_name: '', answer2: '72', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '9×9＝', answer: '81', image_name: '', answer2: '81', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '9×10＝', answer: '90', image_name: '', answer2: '90', etc_2: '', etc_3: '', etc_4: ''}
];