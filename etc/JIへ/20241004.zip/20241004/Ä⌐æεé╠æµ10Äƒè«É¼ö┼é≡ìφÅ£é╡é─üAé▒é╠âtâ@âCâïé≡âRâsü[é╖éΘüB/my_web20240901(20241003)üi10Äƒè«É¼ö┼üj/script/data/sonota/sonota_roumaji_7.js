const mondai = [
    { number: 1, question: '「ひゅ」をローマ字で書きましょう。', answer: 'hyu', image_name: '', answer2: 'hyu', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '「ひょ」をローマ字で書きましょう。', answer: 'hyo', image_name: '', answer2: 'hyo', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '「みゃ」をローマ字で書きましょう。', answer: 'mya', image_name: '', answer2: 'mya', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '「みゅ」をローマ字で書きましょう。', answer: 'my', image_name: '', answer2: 'my', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '「みょ」をローマ字で書きましょう。', answer: 'myo', image_name: '', answer2: 'myo', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '「りゃ」をローマ字で書きましょう。', answer: 'rya', image_name: '', answer2: 'rya', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '「りゅ」をローマ字で書きましょう。', answer: 'ryu', image_name: '', answer2: 'ryu', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: '「りょ」をローマ字で書きましょう。', answer: 'ryo', image_name: '', answer2: 'ryo', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: '「ぎゃ」をローマ字で書きましょう。', answer: 'gya', image_name: '', answer2: 'gya', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: '「ぎゃ」をローマ字で書きましょう。', answer: 'gyu', image_name: '', answer2: 'gyu', etc_2: '', etc_3: '', etc_4: ''}
];