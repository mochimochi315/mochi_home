const mondai = [
    { number: 1, question: 'P103。強く心を打たれた時の、じいさんの心の中は。<BR>残雪は、まるで立派な（　　　ん）のように見えた。', answer: 'にんげん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P103。おとりのがんは、にわとり小屋の中で育てましたが、残雪は、（　　　）の中ですごした。', answer: 'おり', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P103。ひと冬とは、だいたい（　　　）ヶ月ぐらいのこと。', answer: '3', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P103。今度、残雪がやってきたら、じいさんは、堂々と戦って、（　　　）をつかまえようと思っている。', answer: 'がん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];