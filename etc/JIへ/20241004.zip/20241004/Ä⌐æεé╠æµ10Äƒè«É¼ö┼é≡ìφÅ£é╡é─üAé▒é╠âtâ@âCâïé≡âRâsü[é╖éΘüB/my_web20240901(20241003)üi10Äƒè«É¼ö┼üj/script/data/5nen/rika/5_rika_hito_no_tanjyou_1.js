const mondai = [
    { number: 1, question: 'これは、受精後約４週目の図です。<BR>何が動き始めますか。', answer: 'しんぞう', image_name: '5-rika-hito_no_tanjyou-01.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '受精卵は、（　　　）と卵（卵子）が結びついてできる。', answer: 'せいし', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'ウの液体を何といいますか。', answer: 'ようすい', image_name: '5-rika-hito_no_tanjyou-05.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'アを何といいますか。', answer: 'たいばん', image_name: '5-rika-hito_no_tanjyou-06.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P95。生まれたばかりのヒトの子どもの身長は、約（　　　）㎝です。（半角数字で）', answer: '50', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P95。生まれた子どもは、しばらくは、（　　　）を飲んで育つ。', answer: 'ちち', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'イを何といいますか。', answer: 'へそのお', image_name: '5-rika-hito_no_tanjyou-08.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];