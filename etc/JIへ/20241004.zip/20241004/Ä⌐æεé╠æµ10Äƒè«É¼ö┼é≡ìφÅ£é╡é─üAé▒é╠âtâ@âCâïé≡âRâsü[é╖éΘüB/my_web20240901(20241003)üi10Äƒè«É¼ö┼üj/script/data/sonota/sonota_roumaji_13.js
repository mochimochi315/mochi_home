const mondai = [
    { number: 1, question: '「ディズニー」をローマ字で書きましょう。', answer: 'dizunii', image_name: '', answer2: 'dizunii', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: '「ディスプレイ」をローマ字で書きましょう。', answer: 'dispurei', image_name: '', answer2: 'dispurei', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: '「ディスク」をローマ字で書きましょう。', answer: 'disuku', image_name: '', answer2: 'disuku', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: '「ディフェンス」をローマ字で書きましょう。', answer: 'difensu', image_name: '', answer2: 'difensu', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: '「ティッシュ」をローマ字で書きましょう。', answer: 'tisshu', image_name: '', answer2: 'tisshu', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: '「ティラミス」をローマ字で書きましょう。', answer: 'tiramisu', image_name: '', answer2: 'tiramisu', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: '「ヴィクトリア」をローマ字で書きましょう。', answer: 'vikutoria', image_name: '', answer2: 'vikutoria', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: '「ヴァイオリン」をローマ字で書きましょう。', answer: 'vaiorin', image_name: '', answer2: 'vaiorin', etc_2: '', etc_3: '', etc_4: ''}
];