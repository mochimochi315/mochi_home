const mondai = [
    { number: 1, question: '夏から秋にかけて、日本には、（　　　）がやってくる。', answer: 'たいふう', image_name: '', answer2: 'たいふう', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P210　台風や大雨により、川がはんらんすると、家がこわれたり、（　　　）したりする。', answer: 'しんすい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P211　自然災害の発生には、国土の地形や（　　　）の特色が大きく関係します。', answer: 'きこう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P215　住宅地のかさ上げや高台への移転（いてん）などは、（　　　）と呼ばれている。', answer: 'こうきょうじぎょう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P217　地震の（　　　）に強くする改修（かいしゅう）を進める小学校の校舎（こうしゃ）', answer: 'ゆれ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P220　大規模な自然災害を防ぐには（　　　）がある。', answer: 'かぎり', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P219　上の画像は、全国の（　　　）を監視（かんし）する気象庁（きしょうちょう）', answer: 'かざん', image_name: '5_shakai_saigai_03.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P219　上の画像は、「（　　　）防止さく」と呼ばれています。', answer: 'なだれ', image_name: '5_shakai_saigai_01.png', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P218　青森県むつ市では、（　　　）にうまった車から救助（きゅうじょ）する訓練が行われている。', answer: 'どしゃ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 10, question: 'P216　近年、限られた地点で（　　　）のうちに大量の雨がふることが多くなっています。', answer: 'たんじかん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];