const mondai = [
    { number: 1, question: 'P90　これほど多くのまんが本が発行され、読まれているのは、まんがが、（　　）から。', answer: 'りくつぬきにおもしろい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P91　（　　　）方法を「まんがの方法」とよぶことにしましょう。', answer: 'きょうつうしたひょうげんほうほう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P92　ふつうは、上から下へ、（　　　）へと読んでいきます。', answer: 'みぎからひだり', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P92　前のページのまんがは、わく線を破ることで（　　　）を表現しています。', answer: 'つよいおどろき', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P92　また、コマと同じくらい重要なものに、登場人物たちの話す（　　　）（言葉）があります。', answer: 'せりふ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P92　フキダシではなく、絵の中に直接、（　　　）で文字がえがかれていることもあります。', answer: 'て', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P94　（　　　）によって、まんがから受ける感じは、大きくちがってきます。', answer: 'ひょうじょう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P96　背景にかかれているななめの線や丸、点々などは、何のためにかいてあるのですか？<BR>人物の心の動きなどを、（　　　）するため。', answer: 'こうかてきにひょうげん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P98　まんがは、（　　　）でも十分に楽しめるということがわかるでしょう。', answer: 'ことばのことなるくに', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];