const mondai = [
    { number: 1, question: 'P90　まんがには、「一コマまんが」や「四コマまんが」「（　　　）まんが」など、さまざまな種類があります。（カタカナ）', answer: 'ストーリー', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P91　そのおもしろさを生み出す「まんがの方法」についてさぐってみることにします。<BR>上の文章の「その」とは何ですか。（　　　）（カタカナ＋ひらがな）', answer: 'ストーリーまんが', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P92　細かいコマや小さなコマがくり返されると、（　　　）が速まります。（ひらがな＋カタカナ）', answer: 'ものがたりのテンポ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P92　前のページのまんがは、（　　　）ことで強いおどろきを表現しています。', answer: 'わくせんをやぶる', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P92　せりふは、ふつう、「（　　　）」とよばれる円形のわくの中に、本などで使われる印刷用の文字で入っています。（カタカナ）', answer: 'フキダシ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P93　絵の中に直接、手で文字をかくことで、人物の心の動きや動作、（　　　）などを強調している。', answer: 'おと', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P94　登場人物の表情は、まんがの基本的な（　　　）をもとにえがかれています。', answer: 'やくそくごと', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P97　背景にかかれている、せりふでも効果のためでもない言葉は、（　　　）によって語られている言葉である。（カタカナ）', answer: 'ナレーター', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 9, question: 'P98　新しく生み出された「まんがの方法」が、まんがをより（　　　）している。', answer: 'おもしろく', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];