const mondai = [
    { number: 1, question: 'P90～P91　「一コマまんが」や「四コマまんが」「スリーリーまんが」は、すべてまんがの仲間とされています。それはなぜですか。<BR>それは、まんがに特有の、（　　　）が見られるから。', answer: 'きょうつうしたひょうげんほうほう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 2, question: 'P92　ストーリーまんがは、「（　　　）」とよばれる四角いわくの中にえがかれた絵を連続させて、表現されます。（カタカナ）', answer: 'コマ', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 3, question: 'P92　大きなコマや変わった形のコマが入ると、（　　　）が強まります。', answer: 'ばめんのいんしょう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 4, question: 'P92　数種類のコマを組み合わせて、回想や想像、夢など、時間や（　　　）を表現することもあります。', answer: 'こころのうごき', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 5, question: 'P92　そのせりふがどの人物のものなのかは、人物とフキダシとの（　　　）からわかります', answer: 'いちかんけい', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 6, question: 'P94　まんがの絵がらは、実物より（　　　）で、目や口などいくつかの要素が強調されています。', answer: 'とてもたんじゅん', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 7, question: 'P95　このような省略表現があるからこそ、コマとコマとの間の展開を、自分なりに（　　　）しながら読むことができるのです。', answer: 'そうぞう', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''},
    { number: 8, question: 'P98　「まんがの方法」を使ってえがかれた日本のまんがは、広く（　　　）にも親しまれている。', answer: 'かいがいのひとびと', image_name: '', answer2: '', etc_2: '', etc_3: '', etc_4: ''}
];